package com.foridul.gym;

import android.app.Activity;
import android.graphics.*;
import android.media.MediaPlayer;
import android.os.*;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.Locale;

public class ExerciseActivity extends Activity implements TextToSpeech.OnInitListener {
    private int day,index,target;
    private String[][] exercises;
    private String name,mode;
    private TextToSpeech tts;
    private MediaPlayer music;
    private boolean musicOn=true,running=false;
    private TextView count,status,nextLabel;
    private ImageView anim;
    private android.animation.ObjectAnimator moveAnim;
    private CountDownTimer timer;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private int current=0;

    private final Runnable repRunner=new Runnable(){
        @Override public void run(){
            if(!running)return;
            current++;
            count.setText(current+" / "+target);
            speakNumber(current);
            if(current>=target){
                running=false; stopVisualAnimation();
                status.setText("Completed");
                speak("Exercise completed. Great job.");
                nextLabel.setText(index<exercises.length-1?"NEXT EXERCISE":"FINISH DAY");
                return;
            }
            handler.postDelayed(this,1800);
        }
    };

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        day=getIntent().getIntExtra("day",1);
        index=getIntent().getIntExtra("index",0);
        exercises=WorkoutData.exercisesForDay(day);
        if(exercises.length==0){ finish(); return; }
        if(index<0||index>=exercises.length)index=0;
        name=exercises[index][0];
        target=Integer.parseInt(exercises[index][1]);
        mode=exercises[index][2];

        tts=new TextToSpeech(this,this);
        music=MediaPlayer.create(this,R.raw.workout_music);
        if(music!=null){music.setLooping(true);music.setVolume(.14f,.14f);}

        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(22,18,22,24);
        root.setBackgroundColor(Color.WHITE);

        TextView title=text(name.toUpperCase(),23,Color.rgb(30,30,30),true);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        String subtitle="time".equals(mode)?target+" Seconds":"Target "+target+" Reps";
        TextView sub=text(subtitle,14,Color.GRAY,false);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub);

        status=text("Get ready",14,Color.DKGRAY,false);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0,8,0,8);
        root.addView(status);

        anim=new ImageView(this);
        anim.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        anim.setImageResource(imageForExercise(name));
        anim.setBackgroundColor(Color.rgb(247,249,252));
        root.addView(anim,new LinearLayout.LayoutParams(-1,0,1));

        count=text("0 / "+target,38,Color.rgb(32,32,32),true);
        count.setGravity(Gravity.CENTER);
        root.addView(count);

        Button start=button("START");
        root.addView(start);
        start.setOnClickListener(v->startExercise());

        LinearLayout controls=new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        Button musicBtn=button("MUSIC ON");
        Button next=button(index<exercises.length-1?"NEXT EXERCISE":"FINISH DAY");
        nextLabel=next;
        LinearLayout.LayoutParams half=new LinearLayout.LayoutParams(0,-2,1);
        half.setMargins(4,6,4,0);
        controls.addView(musicBtn,half);
        controls.addView(next,new LinearLayout.LayoutParams(0,-2,1));
        root.addView(controls);

        musicBtn.setOnClickListener(v->{
            musicOn=!musicOn;
            musicBtn.setText(musicOn?"MUSIC ON":"MUSIC OFF");
            if(music!=null){
                if(musicOn&&!music.isPlaying())music.start();
                else if(!musicOn&&music.isPlaying())music.pause();
            }
        });
        next.setOnClickListener(v->goNext());

        setContentView(root);
    }

    private void startExercise(){
        if(running)return;
        current=0;
        count.setText("0 / "+target);
        status.setText("Exercise running");
        running=true;
        startVisualAnimation();
        if(musicOn&&music!=null&&!music.isPlaying())music.start();
        speak("Get ready. Start "+name+".");

        if("time".equals(mode)){
            if(timer!=null)timer.cancel();
            timer=new CountDownTimer(target*1000L,1000){
                public void onTick(long ms){
                    current=(int)(target-ms/1000L);
                    int left=(int)Math.ceil(ms/1000.0);
                    count.setText(left+" sec");
                    if(left==10)speak("Ten seconds left.");
                }
                public void onFinish(){
                    running=false;stopVisualAnimation();
                    count.setText("0 sec");
                    status.setText("Completed");
                    speak("Exercise completed.");
                    nextLabel.setText(index<exercises.length-1?"NEXT EXERCISE":"FINISH DAY");
                }
            }.start();
        }else{
            handler.removeCallbacks(repRunner);
            handler.postDelayed(repRunner,1200);
        }
    }

    private int imageForExercise(String n){
        String x=n.toLowerCase(Locale.US);
        if(x.contains("shoulder tap")) return R.drawable.shoulder_taps;
        if(x.contains("knee push")) return R.drawable.knee_push_ups;
        if(x.contains("push")) return R.drawable.push_ups;
        if(x.contains("tricep")) return R.drawable.tricep_dips;
        if(x.contains("plank")) return R.drawable.plank;
        if(x.contains("bent over")) return R.drawable.bent_over_row;
        if(x.contains("bicep")) return R.drawable.bicep_curls;
        if(x.contains("reverse fly")) return R.drawable.reverse_fly;
        if(x.contains("superman")) return R.drawable.superman;
        if(x.contains("back hold")) return R.drawable.back_hold;
        if(x.contains("squat")) return R.drawable.squats;
        if(x.contains("lunge")) return R.drawable.lunges;
        if(x.contains("calf")) return R.drawable.calf_raises;
        if(x.contains("glute")) return R.drawable.glute_bridge;
        return R.drawable.wall_sit;
    }

    private void startVisualAnimation(){
        stopVisualAnimation();
        // The exercise card contains the real movement stages; this gentle motion keeps
        // the workout screen alive without the old stick figure.
        moveAnim=android.animation.ObjectAnimator.ofFloat(anim,"translationY",0f,-12f,0f);
        moveAnim.setDuration(1800);
        moveAnim.setRepeatCount(android.animation.ValueAnimator.INFINITE);
        moveAnim.start();
    }

    private void stopVisualAnimation(){
        if(moveAnim!=null){ moveAnim.cancel(); moveAnim=null; }
        if(anim!=null) anim.setTranslationY(0f);
    }

    private void speakNumber(int n){
        if(n<=12 || n==target) speak(String.valueOf(n));
        else if(n==target-2) speak("Two more.");
    }

    private void goNext(){
        running=false;
        handler.removeCallbacks(repRunner);
        if(timer!=null)timer.cancel();

        if(index<exercises.length-1){
            getIntent().putExtra("index",index+1);
            recreateWithIndex(index+1);
        }else{
            int old=getSharedPreferences("gym_prefs",MODE_PRIVATE).getInt("completed_day",0);
            if(day>old)getSharedPreferences("gym_prefs",MODE_PRIVATE).edit().putInt("completed_day",day).apply();
            speak("Day "+day+" completed. Excellent work.");
            Toast.makeText(this,"Day "+day+" completed!",Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void recreateWithIndex(int newIndex){
        android.content.Intent i=new android.content.Intent(this,ExerciseActivity.class);
        i.putExtra("day",day); i.putExtra("index",newIndex);
        startActivity(i); finish();
    }

    private void speak(String s){
        if(tts!=null)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"gymvoice");
    }

    @Override public void onInit(int statusCode){
        if(statusCode==TextToSpeech.SUCCESS){
            tts.setLanguage(Locale.US);
            tts.setSpeechRate(.94f);
            speak(name+". Get ready.");
        }
    }

    @Override protected void onDestroy(){
        running=false;
        handler.removeCallbacks(repRunner);
        if(timer!=null)timer.cancel();
        if(music!=null){try{music.stop();}catch(Exception ignored){} music.release();}
        if(tts!=null){tts.stop();tts.shutdown();}
        super.onDestroy();
    }

    private Button button(String s){
        Button b=new Button(this);
        b.setText(s);b.setTextSize(14);b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.rgb(47,113,229));
        b.setMinHeight(52);b.setPadding(10,8,10,8);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.setMargins(0,6,0,0); b.setLayoutParams(lp);
        return b;
    }

    private TextView text(String s,int sp,int c,boolean bold){
        TextView t=new TextView(this);
        t.setText(s);t.setTextSize(sp);t.setTextColor(c);
        if(bold)t.setTypeface(null,Typeface.BOLD);
        return t;
    }

}
