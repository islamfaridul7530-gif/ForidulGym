package com.foridul.gym;
import android.app.*; import android.content.*; import android.graphics.*; import android.graphics.drawable.*; import android.os.*; import android.view.*; import android.widget.*;

public class PlanActivity extends Activity {
 LinearLayout list;
 public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.WHITE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
  LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setPadding(28,70,28,0);outer.setBackgroundColor(Color.WHITE);
  LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);
  TextView back=tx("‹",42,Color.BLACK,false);head.addView(back,new LinearLayout.LayoutParams(55,60));back.setOnClickListener(v->finish());
  TextView title=tx("30 Day Fitness",24,Color.BLACK,false);head.addView(title);outer.addView(head);
  int done=getSharedPreferences("gym_prefs",0).getInt("completed_day",0);
  TextView left=tx(Math.max(0,30-done)+"",31,Color.rgb(45,105,220),true); TextView rest=tx(" days left",17,Color.BLACK,true);
  LinearLayout days=new LinearLayout(this);days.setGravity(Gravity.BOTTOM);days.addView(left);days.addView(rest);days.setPadding(4,16,0,12);outer.addView(days);
  ProgressBar pb=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);pb.setMax(30);pb.setProgress(done);outer.addView(pb,new LinearLayout.LayoutParams(-1,14));
  ScrollView sc=new ScrollView(this);list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setPadding(0,28,0,30);sc.addView(list);outer.addView(sc,new LinearLayout.LayoutParams(-1,0,1));setContentView(outer);build();
 }
 void build(){for(int d=1;d<=30;d++){final int day=d;boolean rest="REST".equals(WorkoutData.typeForDay(d));
   LinearLayout card=new LinearLayout(this);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(28,20,24,20);GradientDrawable bg=new GradientDrawable();bg.setColor(Color.rgb(248,249,252));bg.setCornerRadius(28);card.setBackground(bg);
   LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);card.addView(info,new LinearLayout.LayoutParams(0,-2,1));
   info.addView(tx("Day "+d,22,Color.rgb(55,55,60),true));
   String sub=rest?"Rest":WorkoutData.exercisesForDay(d).length+" Exercises";TextView st=tx(sub,14,Color.rgb(135,135,140),false);st.setPadding(0,5,0,0);info.addView(st);
   if(rest){TextView cup=tx("☕",27,Color.rgb(150,150,155),false);cup.setGravity(Gravity.CENTER);card.addView(cup,new LinearLayout.LayoutParams(58,58));}
   LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,14);list.addView(card,lp);
   card.setOnClickListener(v->{Intent i=new Intent(this,DayActivity.class);i.putExtra("day",day);startActivity(i);});
 }}
 TextView tx(String s,int z,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
}