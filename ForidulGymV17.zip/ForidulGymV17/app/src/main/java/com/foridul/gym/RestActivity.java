package com.foridul.gym;
import android.app.*;import android.content.*;import android.graphics.*;import android.os.*;import android.view.*;import android.widget.*;

public class RestActivity extends Activity{
 private int day,nextIndex,left; private TextView timer; private CountDownTimer cd;
 public void onCreate(Bundle b){super.onCreate(b);day=getIntent().getIntExtra("day",1);nextIndex=getIntent().getIntExtra("nextIndex",1);left=getSharedPreferences("gym_prefs",0).getInt("rest_seconds",30);
  LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER_HORIZONTAL);Ui.safe(this,root,28,28,28,30);root.setBackgroundColor(Color.WHITE);
  TextView small=Ui.text(this,"REST TIME",16,Ui.blue(),true);small.setGravity(Gravity.CENTER);root.addView(small);
  TextView title=Ui.text(this,"Catch your breath",29,Color.BLACK,true);title.setGravity(Gravity.CENTER);title.setPadding(0,18,0,10);root.addView(title);
  timer=Ui.text(this,left+"",72,Color.rgb(25,25,28),true);timer.setGravity(Gravity.CENTER);root.addView(timer,new LinearLayout.LayoutParams(-1,0,1));
  String goal=getSharedPreferences("gym_prefs",0).getString("goal","GAIN");String[][] ex=WorkoutData.exercisesForDay(day,goal);String next=nextIndex<ex.length?ex[nextIndex][0]:"Next Exercise";
  TextView n=Ui.text(this,"Up next: "+next,18,Color.DKGRAY,true);n.setGravity(Gravity.CENTER);n.setPadding(0,0,0,22);root.addView(n);
  Button plus=Ui.button(this,"+ 20 SEC");root.addView(plus);plus.setOnClickListener(v->{left+=20;timer.setText(""+left);startTimer();});
  Button skip=Ui.button(this,"SKIP REST");LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,12,0,0);root.addView(skip,lp);skip.setOnClickListener(v->go());setContentView(root);startTimer(); }
 private void startTimer(){if(cd!=null)cd.cancel();cd=new CountDownTimer(left*1000L,1000){public void onTick(long ms){left=(int)Math.ceil(ms/1000.0);timer.setText(""+left);}public void onFinish(){left=0;timer.setText("0");go();}}.start();}
 private void go(){if(cd!=null)cd.cancel();Intent i=new Intent(this,ExerciseActivity.class);i.putExtra("day",day);i.putExtra("index",nextIndex);startActivity(i);finish();}
 protected void onDestroy(){if(cd!=null)cd.cancel();super.onDestroy();}
}
