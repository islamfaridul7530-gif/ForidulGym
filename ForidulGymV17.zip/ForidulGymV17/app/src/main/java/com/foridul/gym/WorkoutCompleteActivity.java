package com.foridul.gym;
import android.app.*;import android.content.*;import android.graphics.*;import android.os.*;import android.view.*;import android.widget.*;
public class WorkoutCompleteActivity extends Activity{
 public void onCreate(Bundle b){super.onCreate(b);int day=getIntent().getIntExtra("day",1);android.content.SharedPreferences p=getSharedPreferences("gym_prefs",0);String goal=p.getString("goal","GAIN");String[][] ex=WorkoutData.exercisesForDay(day,goal);long start=p.getLong("session_start",0);int actual=start>0?(int)Math.max(1,(System.currentTimeMillis()-start)/60000L):WorkoutData.estimatedMinutes(day);
  LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER_HORIZONTAL);Ui.safe(this,root,28,30,28,30);root.setBackgroundColor(Color.rgb(248,249,252));
  TextView check=Ui.text(this,"✓",64,Ui.blue(),true);check.setGravity(Gravity.CENTER);root.addView(check);
  TextView title=Ui.text(this,"Workout Complete!",30,Color.BLACK,true);title.setGravity(Gravity.CENTER);root.addView(title);
  TextView sub=Ui.text(this,"Day "+day+" finished. Great work!",16,Color.GRAY,false);sub.setGravity(Gravity.CENTER);sub.setPadding(0,8,0,28);root.addView(sub);
  LinearLayout card=Ui.card(this);card.setOrientation(LinearLayout.HORIZONTAL);card.addView(stat(ex.length+"","EXERCISES"),new LinearLayout.LayoutParams(0,-2,1));card.addView(stat(actual+"m","TIME"),new LinearLayout.LayoutParams(0,-2,1));card.addView(stat(WorkoutData.estimatedCalories(day)+"","KCAL"),new LinearLayout.LayoutParams(0,-2,1));root.addView(card,new LinearLayout.LayoutParams(-1,-2));
  TextView msg=Ui.text(this,"Your progress has been saved.",15,Color.DKGRAY,false);msg.setGravity(Gravity.CENTER);msg.setPadding(0,26,0,18);root.addView(msg,new LinearLayout.LayoutParams(-1,0,1));
  Button home=Ui.button(this,"BACK TO HOME");root.addView(home);home.setOnClickListener(v->{Intent i=new Intent(this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);finish();});setContentView(root); }
 LinearLayout stat(String v,String l){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setGravity(Gravity.CENTER);TextView a=Ui.text(this,v,25,Color.BLACK,true);a.setGravity(Gravity.CENTER);TextView z=Ui.text(this,l,11,Color.GRAY,false);z.setGravity(Gravity.CENTER);x.addView(a);x.addView(z);return x;}
}
