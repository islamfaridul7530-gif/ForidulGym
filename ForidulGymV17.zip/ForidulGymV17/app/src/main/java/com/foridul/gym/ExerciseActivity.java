package com.foridul.gym;

import android.app.Activity;
import android.graphics.*;
import android.media.MediaPlayer;
import android.os.*;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.graphics.drawable.ColorDrawable;
import android.widget.*;
import java.util.Locale;

public class ExerciseActivity extends Activity implements TextToSpeech.OnInitListener {
    private int day,index,target;
    private String[][] exercises;
    private String name,mode;
    private TextToSpeech tts;
    private MediaPlayer music;
    private boolean musicOn=true,running=false,paused=false;
    private TextView count,status,nextLabel;
    private Button startBtn,pauseBtn;
    private int remainingSeconds=0;
    private ExerciseView anim;
    private CountDownTimer timer;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private int current=0;

    private final Runnable repRunner=new Runnable(){
        @Override public void run(){
            if(!running)return;
            current++;
            count.setText(current+" / "+target);
            speakNumber(current);
            if(current>=target){
                running=false; 
                status.setText("Completed");
                speak("Exercise completed. Great job.");
                if(anim!=null) anim.setRunning(false);
                startBtn.setText("DONE");
                nextLabel.setText(index<exercises.length-1?"REST & NEXT":"FINISH DAY");
                return;
            }
            handler.postDelayed(this,1800);
        }
    };

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        day=getIntent().getIntExtra("day",1);
        index=getIntent().getIntExtra("index",0);
        String goal=getSharedPreferences("gym_prefs",0).getString("goal","GAIN");
        exercises=WorkoutData.exercisesForDay(day,goal);
        if(exercises.length==0){ finish(); return; }
        if(index<0||index>=exercises.length)index=0;
        name=exercises[index][0];
        target=Integer.parseInt(exercises[index][1]);
        mode=exercises[index][2];

        musicOn=getSharedPreferences("gym_prefs",0).getBoolean("music_enabled",true);
        tts=new TextToSpeech(this,this);
        music=MediaPlayer.create(this,R.raw.workout_music);
        if(index==0) getSharedPreferences("gym_prefs",0).edit().putLong("session_start",System.currentTimeMillis()).apply();
        if(music!=null){music.setLooping(true);music.setVolume(.14f,.14f);}

        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        Ui.safe(this,root,22,18,22,24);
        root.setBackgroundColor(Color.WHITE);

        TextView title=text(name.toUpperCase(),23,Color.rgb(30,30,30),true);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        String subtitle="time".equals(mode)?target+" Seconds":"Target "+target+" Reps";
        TextView sub=text(subtitle,14,Color.GRAY,false);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub);

        status=text("Get ready",14,Color.DKGRAY,false);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0,8,0,8);
        root.addView(status);

        anim=new ExerciseView(this,name);
        root.addView(anim,new LinearLayout.LayoutParams(-1,0,1));

        count=text("0 / "+target,38,Color.rgb(32,32,32),true);
        count.setGravity(Gravity.CENTER);
        root.addView(count);

        startBtn=button("START");
        root.addView(startBtn);
        startBtn.setOnClickListener(v->startExercise());

        LinearLayout actionRow=new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        Button prev=button("PREVIOUS");
        pauseBtn=button("PAUSE");
        LinearLayout.LayoutParams actionHalf=new LinearLayout.LayoutParams(0,-2,1);
        actionHalf.setMargins(4,6,4,0);
        actionRow.addView(prev,actionHalf);
        actionRow.addView(pauseBtn,new LinearLayout.LayoutParams(0,-2,1));
        root.addView(actionRow);
        prev.setEnabled(index>0); prev.setAlpha(index>0?1f:.45f);
        prev.setOnClickListener(v->{ if(index>0){ stopExercise(); recreateWithIndex(index-1); } });
        pauseBtn.setOnClickListener(v->togglePause());

        LinearLayout controls=new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        Button musicBtn=button(musicOn?"MUSIC ON":"MUSIC OFF");
        Button next=button(index<exercises.length-1?"NEXT EXERCISE":"FINISH DAY");
        nextLabel=next;
        LinearLayout.LayoutParams half=new LinearLayout.LayoutParams(0,-2,1);
        half.setMargins(4,6,4,0);
        controls.addView(musicBtn,half);
        controls.addView(next,new LinearLayout.LayoutParams(0,-2,1));
        root.addView(controls);

        musicBtn.setOnClickListener(v->{
            musicOn=!musicOn;
            musicBtn.setText(musicOn?"MUSIC ON":"MUSIC OFF");
            if(music!=null){
                if(musicOn&&!music.isPlaying())music.start();
                else if(!musicOn&&music.isPlaying())music.pause();
            }
        });
        next.setOnClickListener(v->goNext());

        setContentView(root);
    }

    private void startExercise(){
        if(paused){ resumeExercise(); return; }
        if(running)return;
        current=0; remainingSeconds=target;
        running=true; paused=false;
        startBtn.setText("RUNNING"); pauseBtn.setText("PAUSE");
        if(musicOn&&music!=null&&!music.isPlaying())music.start();
        startCountdown(3);
    }

    private void startCountdown(int n){
        if(!running)return;
        if(n>0){
            status.setText("Starting in "+n);
            count.setText(String.valueOf(n));
            speak(String.valueOf(n));
            handler.postDelayed(() -> startCountdown(n-1),850);
            return;
        }
        count.setText("time".equals(mode)?remainingSeconds+" sec":"0 / "+target);
        status.setText("Exercise running");
        if(anim!=null) anim.setRunning(true);
        speak("Start "+name+".");
        if("time".equals(mode)) startTimeTimer(remainingSeconds);
        else { handler.removeCallbacks(repRunner); handler.postDelayed(repRunner,1200); }
    }

    private void startTimeTimer(int seconds){
        if(timer!=null)timer.cancel();
        timer=new CountDownTimer(seconds*1000L,1000){
            public void onTick(long ms){
                remainingSeconds=(int)Math.ceil(ms/1000.0);
                count.setText(remainingSeconds+" sec");
                if(remainingSeconds==10)speak("Ten seconds left.");
            }
            public void onFinish(){
                remainingSeconds=0; running=false; paused=false;
                if(anim!=null) anim.setRunning(false);
                count.setText("0 sec"); status.setText("Completed");
                startBtn.setText("DONE"); pauseBtn.setText("PAUSE");
                speak("Exercise completed.");
                nextLabel.setText(index<exercises.length-1?"REST & NEXT":"FINISH DAY");
            }
        }.start();
    }

    private void togglePause(){
        if(paused){ resumeExercise(); return; }
        if(!running)return;
        running=false; paused=true;
        handler.removeCallbacks(repRunner);
        if(timer!=null)timer.cancel();
        if(anim!=null)anim.setRunning(false);
        status.setText("Paused"); pauseBtn.setText("RESUME"); startBtn.setText("PAUSED");
        speak("Paused");
    }

    private void resumeExercise(){
        if(!paused)return;
        paused=false; running=true;
        status.setText("Exercise running"); pauseBtn.setText("PAUSE"); startBtn.setText("RUNNING");
        if(anim!=null)anim.setRunning(true);
        if("time".equals(mode)) startTimeTimer(Math.max(1,remainingSeconds));
        else handler.postDelayed(repRunner,700);
        speak("Resume");
    }

    private void stopExercise(){
        running=false; paused=false;
        handler.removeCallbacks(repRunner);
        if(timer!=null)timer.cancel();
        if(anim!=null)anim.setRunning(false);
    }

    private void speakNumber(int n){
        if(n<=12 || n==target) speak(String.valueOf(n));
        else if(n==target-2) speak("Two more.");
    }

    private void goNext(){
        stopExercise();
        if(index<exercises.length-1){
            android.content.Intent i=new android.content.Intent(this,RestActivity.class);
            i.putExtra("day",day); i.putExtra("nextIndex",index+1);
            startActivity(i); finish();
        }else{
            completeDay();
        }
    }

    private void completeDay(){
        android.content.SharedPreferences p=getSharedPreferences("gym_prefs",MODE_PRIVATE);
        int old=p.getInt("completed_day",0);
        if(day>old)p.edit().putInt("completed_day",day).apply();
        int workouts=p.getInt("total_workouts",0)+1;
        int mins=WorkoutData.estimatedMinutes(day);
        int kcal=WorkoutData.estimatedCalories(day);
        p.edit().putInt("total_workouts",workouts)
         .putInt("total_minutes",p.getInt("total_minutes",0)+mins)
         .putInt("total_kcal",p.getInt("total_kcal",0)+kcal)
         .putLong("last_workout_time",System.currentTimeMillis()).apply();
        speak("Day "+day+" completed. Excellent work.");
        android.content.Intent i=new android.content.Intent(this,WorkoutCompleteActivity.class);
        i.putExtra("day",day); startActivity(i); finish();
    }

    private void recreateWithIndex(int newIndex){
        android.content.Intent i=new android.content.Intent(this,ExerciseActivity.class);
        i.putExtra("day",day); i.putExtra("index",newIndex);
        startActivity(i); finish();
    }

    private void speak(String s){
        if(!getSharedPreferences("gym_prefs",0).getBoolean("voice_enabled",true))return;
        if(tts!=null)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"gymvoice");
    }

    @Override public void onInit(int statusCode){
        if(statusCode==TextToSpeech.SUCCESS){
            tts.setLanguage(Locale.US);
            tts.setSpeechRate(.94f);
            speak(name+". Get ready.");
        }
    }

    @Override protected void onDestroy(){
        running=false;
        if(anim!=null) anim.setRunning(false);
        handler.removeCallbacks(repRunner);
        if(timer!=null)timer.cancel();
        if(music!=null){try{music.stop();}catch(Exception ignored){} music.release();}
        if(tts!=null){tts.stop();tts.shutdown();}
        super.onDestroy();
    }

    private Button button(String s){
        Button b=new Button(this);
        b.setText(s);b.setTextSize(14);b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.rgb(47,113,229));
        b.setMinHeight(52);b.setPadding(10,8,10,8);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.setMargins(0,6,0,0); b.setLayoutParams(lp);
        return b;
    }

    private TextView text(String s,int sp,int c,boolean bold){
        TextView t=new TextView(this);
        t.setText(s);t.setTextSize(sp);t.setTextColor(c);
        if(bold)t.setTypeface(null,Typeface.BOLD);
        return t;
    }

    public static class ExerciseView extends FrameLayout{
        private final Handler h=new Handler(Looper.getMainLooper());
        private final ImageView image;
        private final TextView cue;
        private final int[] frames=new int[3];
        private boolean running=false;
        private int pos=0, dir=1;

        public ExerciseView(android.content.Context c,String n){
            super(c);
            setBackgroundColor(Color.rgb(247,249,252));
            setPadding(18,18,18,18);
            String key=keyFor(n);
            frames[0]=res(c,"ex_"+key+"_1"); frames[1]=res(c,"ex_"+key+"_2"); frames[2]=res(c,"ex_"+key+"_3");
            image=new ImageView(c);
            image.setScaleType(ImageView.ScaleType.FIT_CENTER);
            image.setAdjustViewBounds(true);
            // Source exercise frames are white line art on transparent background.
            // Tint them dark blue so they remain clearly visible on the light workout card.
            image.setColorFilter(Color.rgb(24,64,120), android.graphics.PorterDuff.Mode.SRC_IN);
            image.setPadding(4,4,4,4);
            LayoutParams ip=new LayoutParams(-1,-1); ip.setMargins(0,32,0,46); addView(image,ip);
            cue=new TextView(c); cue.setText("READY • WATCH THE FULL BODY POSITION"); cue.setTextSize(14); cue.setTextColor(Color.rgb(47,113,229)); cue.setTypeface(null,Typeface.BOLD); cue.setGravity(Gravity.CENTER);
            LayoutParams cp=new LayoutParams(-1,48,Gravity.BOTTOM); addView(cue,cp);
            showFrame(0);
        }
        private int res(android.content.Context c,String name){return c.getResources().getIdentifier(name,"drawable",c.getPackageName());}
        private static String keyFor(String n){
            String x=n.toLowerCase(Locale.US);
            if(x.contains("jumping jack"))return "jumping_jacks"; if(x.contains("mountain climber"))return "mountain_climbers";
            if(x.contains("shoulder tap"))return "shoulder_taps"; if(x.contains("knee push"))return "knee_push_ups";
            if(x.equals("push ups")||x.equals("push up"))return "push_ups"; if(x.contains("tricep dip"))return "tricep_dips";
            if(x.equals("plank"))return "plank"; if(x.contains("high knee"))return "high_knees"; if(x.contains("bent over row"))return "bent_over_row";
            if(x.contains("bicep curl"))return "bicep_curls"; if(x.contains("reverse fly"))return "reverse_fly"; if(x.equals("superman"))return "superman";
            if(x.contains("back hold"))return "back_hold"; if(x.contains("squat"))return "squats"; if(x.contains("lunge"))return "lunges";
            if(x.contains("calf raise"))return "calf_raises"; if(x.contains("glute bridge"))return "glute_bridge"; if(x.contains("wall sit"))return "wall_sit";
            return "push_ups";
        }
        private void showFrame(int i){ if(frames[i]!=0) image.setImageResource(frames[i]); }
        private final Runnable loop=new Runnable(){public void run(){if(!running)return; pos+=dir;if(pos>=2){pos=2;dir=-1;}else if(pos<=0){pos=0;dir=1;}showFrame(pos);h.postDelayed(this,420);}};
        public void setRunning(boolean x){running=x;h.removeCallbacks(loop);cue.setText(x?"FOLLOW THE MOVEMENT":"READY • WATCH THE FULL BODY POSITION");if(x){pos=0;dir=1;showFrame(0);h.postDelayed(loop,420);} }
        @Override protected void onDetachedFromWindow(){h.removeCallbacks(loop);super.onDetachedFromWindow();}
    }
}
