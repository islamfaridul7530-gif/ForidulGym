Foridul Gym V14
- Rest screen with Skip and +20 sec
- Pause/Resume and Previous Exercise
- Workout Complete summary
- Better Reports with progress + weight history
- Editable workout settings and profile
- Completed/current day indicators
- Existing V13 exercise animations retained for now
