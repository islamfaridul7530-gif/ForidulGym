package com.foridul.gym;

import android.app.Activity;
import android.graphics.*;
import android.media.MediaPlayer;
import android.os.*;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.Locale;

public class ExerciseActivity extends Activity implements TextToSpeech.OnInitListener {
    private int day,index,target;
    private String[][] exercises;
    private String name,mode;
    private TextToSpeech tts;
    private MediaPlayer music;
    private boolean musicOn=true,running=false;
    private TextView count,status,nextLabel;
    private ExerciseView anim;
    private CountDownTimer timer;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private int current=0;

    private final Runnable repRunner=new Runnable(){
        @Override public void run(){
            if(!running)return;
            current++;
            count.setText(current+" / "+target);
            speakNumber(current);
            if(current>=target){
                running=false; 
                status.setText("Completed");
                speak("Exercise completed. Great job.");
                nextLabel.setText(index<exercises.length-1?"NEXT EXERCISE":"FINISH DAY");
                return;
            }
            handler.postDelayed(this,1800);
        }
    };

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        day=getIntent().getIntExtra("day",1);
        index=getIntent().getIntExtra("index",0);
        String goal=getSharedPreferences("gym_prefs",0).getString("goal","GAIN");
        exercises=WorkoutData.exercisesForDay(day,goal);
        if(exercises.length==0){ finish(); return; }
        if(index<0||index>=exercises.length)index=0;
        name=exercises[index][0];
        target=Integer.parseInt(exercises[index][1]);
        mode=exercises[index][2];

        tts=new TextToSpeech(this,this);
        music=MediaPlayer.create(this,R.raw.workout_music);
        if(music!=null){music.setLooping(true);music.setVolume(.14f,.14f);}

        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        Ui.safe(this,root,22,18,22,24);
        root.setBackgroundColor(Color.WHITE);

        TextView title=text(name.toUpperCase(),23,Color.rgb(30,30,30),true);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        String subtitle="time".equals(mode)?target+" Seconds":"Target "+target+" Reps";
        TextView sub=text(subtitle,14,Color.GRAY,false);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub);

        status=text("Get ready",14,Color.DKGRAY,false);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0,8,0,8);
        root.addView(status);

        anim=new ExerciseView(this,name);
        root.addView(anim,new LinearLayout.LayoutParams(-1,0,1));

        count=text("0 / "+target,38,Color.rgb(32,32,32),true);
        count.setGravity(Gravity.CENTER);
        root.addView(count);

        Button start=button("START");
        root.addView(start);
        start.setOnClickListener(v->startExercise());

        LinearLayout controls=new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        Button musicBtn=button("MUSIC ON");
        Button next=button(index<exercises.length-1?"NEXT EXERCISE":"FINISH DAY");
        nextLabel=next;
        LinearLayout.LayoutParams half=new LinearLayout.LayoutParams(0,-2,1);
        half.setMargins(4,6,4,0);
        controls.addView(musicBtn,half);
        controls.addView(next,new LinearLayout.LayoutParams(0,-2,1));
        root.addView(controls);

        musicBtn.setOnClickListener(v->{
            musicOn=!musicOn;
            musicBtn.setText(musicOn?"MUSIC ON":"MUSIC OFF");
            if(music!=null){
                if(musicOn&&!music.isPlaying())music.start();
                else if(!musicOn&&music.isPlaying())music.pause();
            }
        });
        next.setOnClickListener(v->goNext());

        setContentView(root);
    }

    private void startExercise(){
        if(running)return;
        current=0;
        running=true;
        if(musicOn&&music!=null&&!music.isPlaying())music.start();
        startCountdown(3);
    }

    private void startCountdown(int n){
        if(!running)return;
        if(n>0){
            status.setText("Starting in "+n);
            count.setText(String.valueOf(n));
            speak(String.valueOf(n));
            handler.postDelayed(() -> startCountdown(n-1),850);
            return;
        }
        count.setText("0 / "+target);
        status.setText("Exercise running");
        if(anim!=null) anim.setRunning(true);
        speak("Start "+name+".");

        if("time".equals(mode)){
            if(timer!=null)timer.cancel();
            timer=new CountDownTimer(target*1000L,1000){
                public void onTick(long ms){
                    current=(int)(target-ms/1000L);
                    int left=(int)Math.ceil(ms/1000.0);
                    count.setText(left+" sec");
                    if(left==10)speak("Ten seconds left.");
                }
                public void onFinish(){
                    running=false;
                    if(anim!=null) anim.setRunning(false);
                    count.setText("0 sec");
                    status.setText("Completed");
                    speak("Exercise completed.");
                    nextLabel.setText(index<exercises.length-1?"NEXT EXERCISE":"FINISH DAY");
                }
            }.start();
        }else{
            handler.removeCallbacks(repRunner);
            handler.postDelayed(repRunner,1200);
        }
    }

    private void speakNumber(int n){
        if(n<=12 || n==target) speak(String.valueOf(n));
        else if(n==target-2) speak("Two more.");
    }

    private void goNext(){
        running=false;
        if(anim!=null) anim.setRunning(false);
        handler.removeCallbacks(repRunner);
        if(timer!=null)timer.cancel();

        if(index<exercises.length-1){
            getIntent().putExtra("index",index+1);
            recreateWithIndex(index+1);
        }else{
            int old=getSharedPreferences("gym_prefs",MODE_PRIVATE).getInt("completed_day",0);
            if(day>old)getSharedPreferences("gym_prefs",MODE_PRIVATE).edit().putInt("completed_day",day).apply();
            speak("Day "+day+" completed. Excellent work.");
            Toast.makeText(this,"Day "+day+" completed!",Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void recreateWithIndex(int newIndex){
        android.content.Intent i=new android.content.Intent(this,ExerciseActivity.class);
        i.putExtra("day",day); i.putExtra("index",newIndex);
        startActivity(i); finish();
    }

    private void speak(String s){
        if(tts!=null)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"gymvoice");
    }

    @Override public void onInit(int statusCode){
        if(statusCode==TextToSpeech.SUCCESS){
            tts.setLanguage(Locale.US);
            tts.setSpeechRate(.94f);
            speak(name+". Get ready.");
        }
    }

    @Override protected void onDestroy(){
        running=false;
        if(anim!=null) anim.setRunning(false);
        handler.removeCallbacks(repRunner);
        if(timer!=null)timer.cancel();
        if(music!=null){try{music.stop();}catch(Exception ignored){} music.release();}
        if(tts!=null){tts.stop();tts.shutdown();}
        super.onDestroy();
    }

    private Button button(String s){
        Button b=new Button(this);
        b.setText(s);b.setTextSize(14);b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.rgb(47,113,229));
        b.setMinHeight(52);b.setPadding(10,8,10,8);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.setMargins(0,6,0,0); b.setLayoutParams(lp);
        return b;
    }

    private TextView text(String s,int sp,int c,boolean bold){
        TextView t=new TextView(this);
        t.setText(s);t.setTextSize(sp);t.setTextColor(c);
        if(bold)t.setTypeface(null,Typeface.BOLD);
        return t;
    }

    public static class ExerciseView extends View{
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Handler h=new Handler(Looper.getMainLooper());
        private boolean running=false;
        private float phase=0;
        private final String name;
        private final int skin=Color.rgb(218,157,118), shirt=Color.rgb(47,113,229), shorts=Color.rgb(32,38,48), shoe=Color.rgb(25,28,34);

        public ExerciseView(android.content.Context c,String n){
            super(c); name=n.toLowerCase(Locale.US); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND);
        }
        private final Runnable loop=new Runnable(){ @Override public void run(){ if(!running)return; phase+=.035f; if(phase>1)phase=0; invalidate(); h.postDelayed(this,33); } };
        public void setRunning(boolean x){running=x;h.removeCallbacks(loop);if(x)h.post(loop);invalidate();}

        @Override protected void onDraw(Canvas c){
            super.onDraw(c); c.drawColor(Color.rgb(247,249,252));
            float w=getWidth(), H=getHeight(); if(w<=0||H<=0)return;
            float q=running?(float)((1-Math.cos(phase*2*Math.PI))/2):0f;
            p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(240,244,250));c.drawRoundRect(w*.035f,H*.14f,w*.965f,H*.90f,28,28,p);p.setColor(Color.rgb(205,213,224));p.setStrokeWidth(4);c.drawLine(w*.08f,H*.86f,w*.92f,H*.86f,p);
            if(name.contains("jumping jack")) jumpingJack(c,w,H,q);
            else if(name.contains("mountain climber")) mountainClimber(c,w,H,q);
            else if(name.contains("high knee")) highKnees(c,w,H,q);
            else if(name.contains("shoulder tap")) shoulderTap(c,w,H,q);
            else if(name.contains("knee push")) kneePush(c,w,H,q);
            else if(name.equals("push ups")||name.equals("push up")) pushup(c,w,H,q);
            else if(name.contains("tricep dip")) tricepDip(c,w,H,q);
            else if(name.equals("plank")) plank(c,w,H,q);
            else if(name.contains("bent over row")) bentRow(c,w,H,q);
            else if(name.contains("bicep curl")) bicepCurl(c,w,H,q);
            else if(name.contains("reverse fly")) reverseFly(c,w,H,q);
            else if(name.equals("superman")) superman(c,w,H,q);
            else if(name.contains("back hold")) backHold(c,w,H,q);
            else if(name.equals("squats")||name.equals("squat")) squat(c,w,H,q);
            else if(name.contains("lunge")) lunge(c,w,H,q);
            else if(name.contains("calf raise")) calfRaise(c,w,H,q);
            else if(name.contains("glute bridge")) gluteBridge(c,w,H,q);
            else if(name.contains("wall sit")) wallSit(c,w,H,q);
            else bicepCurl(c,w,H,q);
            p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(Math.max(22,H*.040f));p.setColor(Color.rgb(47,113,229));
            String label=running?"FOLLOW THE MOVEMENT":"READY"; float tw=p.measureText(label);c.drawText(label,(w-tw)/2,H*.085f,p);
            p.setTypeface(Typeface.DEFAULT);p.setTextSize(Math.max(14,H*.025f));p.setColor(Color.rgb(100,108,120));
            String cue="Copy the body position shown";float cw=p.measureText(cue);c.drawText(cue,(w-cw)/2,H*.125f,p);
        }

        private void seg(Canvas c,float x1,float y1,float x2,float y2,float width,int color){
            float dx=x2-x1,dy=y2-y1,len=(float)Math.sqrt(dx*dx+dy*dy);
            if(len<1)return;
            float ang=(float)Math.toDegrees(Math.atan2(dy,dx));
            c.save();c.translate(x1,y1);c.rotate(ang);
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            float half=width*.52f;
            c.drawRoundRect(0,-half,len,half,half,half,p);
            c.drawCircle(0,0,half,p);c.drawCircle(len,0,half,p);
            p.setColor(Color.argb(36,255,255,255));
            c.drawRoundRect(width*.12f,-half*.56f,Math.max(width*.15f,len-width*.12f),-half*.10f,half*.30f,half*.30f,p);
            c.restore();
        }

        private void head(Canvas c,float x,float y,float r){
            p.setStyle(Paint.Style.FILL);
            p.setColor(skin);
            c.drawOval(x-r*.86f,y-r,x+r*.86f,y+r,p);
            p.setColor(Color.rgb(48,39,34));
            c.drawArc(x-r*.90f,y-r*.99f,x+r*.90f,y+r*.30f,185,170,true,p);
            p.setColor(skin);c.drawCircle(x-r*.82f,y+r*.06f,r*.16f,p);
            p.setColor(Color.rgb(50,45,43));c.drawCircle(x+r*.28f,y-r*.08f,r*.065f,p);
            p.setColor(Color.rgb(120,78,62));p.setStrokeWidth(Math.max(2,r*.055f));
            c.drawLine(x+r*.31f,y+r*.31f,x+r*.55f,y+r*.27f,p);
            p.setColor(skin);
            c.drawRoundRect(x-r*.27f,y+r*.72f,x+r*.27f,y+r*1.22f,r*.12f,r*.12f,p);
        }

        private void torso(Canvas c,float sx,float sy,float hx,float hy,float width){
            float dx=hx-sx,dy=hy-sy,len=(float)Math.sqrt(dx*dx+dy*dy);
            float ang=(float)Math.toDegrees(Math.atan2(dy,dx));
            c.save();c.translate(sx,sy);c.rotate(ang);
            Path body=new Path();
            body.moveTo(0,-width*.62f);
            body.lineTo(len*.22f,-width*.76f);
            body.lineTo(len*.86f,-width*.50f);
            body.lineTo(len,width*.42f);
            body.lineTo(len*.88f,width*.58f);
            body.lineTo(len*.22f,width*.74f);
            body.lineTo(0,width*.62f);
            body.close();
            p.setStyle(Paint.Style.FILL);p.setColor(shirt);c.drawPath(body,p);
            p.setColor(Color.argb(42,255,255,255));
            c.drawRoundRect(len*.12f,-width*.45f,len*.70f,-width*.18f,width*.12f,width*.12f,p);
            c.restore();
            p.setColor(shorts);
            c.drawOval(hx-width*.62f,hy-width*.44f,hx+width*.62f,hy+width*.58f,p);
        }

        private void dumbbell(Canvas c,float x,float y,float scale){
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(52,57,66));
            c.drawRoundRect(x-19*scale,y-4*scale,x+19*scale,y+4*scale,3*scale,3*scale,p);
            c.drawRoundRect(x-27*scale,y-14*scale,x-16*scale,y+14*scale,4*scale,4*scale,p);
            c.drawRoundRect(x+16*scale,y-14*scale,x+27*scale,y+14*scale,4*scale,4*scale,p);
            p.setColor(Color.rgb(96,105,118));
            c.drawRoundRect(x-23*scale,y-10*scale,x-18*scale,y+10*scale,2*scale,2*scale,p);
            c.drawRoundRect(x+18*scale,y-10*scale,x+23*scale,y+10*scale,2*scale,2*scale,p);
        }
        private void shoe(Canvas c,float x,float y,float dir){
            p.setStyle(Paint.Style.FILL);p.setColor(shoe);
            float toe=x+24*dir;
            RectF r=new RectF(Math.min(x-13,toe),y-8,Math.max(x-13,toe),y+9);
            c.drawRoundRect(r,8,8,p);
            p.setColor(Color.WHITE);
            c.drawRoundRect(Math.min(x-10,toe),y+5,Math.max(x-10,toe),y+8,3,3,p);
        }

        private void standingBase(Canvas c,float w,float H,float cx,float bodyY,float armLift,float kneeLift){
            float r=H*.045f, shoulderY=bodyY+H*.10f, hipY=bodyY+H*.34f;
            head(c,cx,bodyY,r);torso(c,cx,shoulderY,cx,hipY,H*.075f);
            float handY=shoulderY+H*(.20f-.25f*armLift);
            seg(c,cx-H*.03f,shoulderY,cx-w*.16f,handY,H*.034f,skin);seg(c,cx+H*.03f,shoulderY,cx+w*.16f,handY,H*.034f,skin);
            float lkx=cx-w*.08f, rkx=cx+w*.08f;
            float lky=hipY+H*(.17f-.12f*kneeLift), rky=hipY+H*.17f;
            seg(c,cx-H*.03f,hipY,lkx,lky,H*.045f,shorts);seg(c,lkx,lky,cx-w*.10f,H*.84f,H*.038f,skin);
            seg(c,cx+H*.03f,hipY,rkx,rky,H*.045f,shorts);seg(c,rkx,rky,cx+w*.10f,H*.84f,H*.038f,skin);
            shoe(c,cx-w*.10f,H*.845f,-1);shoe(c,cx+w*.10f,H*.845f,1);
        }

        private void pushup(Canvas c,float w,float H,float q){
            float y=H*(.42f+.17f*q), sx=w*.66f, sy=y, hx=w*.42f, hy=y+H*.035f, footx=w*.17f, floor=H*.84f;
            head(c,w*.74f,y-H*.045f,H*.04f);torso(c,sx,sy,hx,hy,H*.065f);
            float elbowx=w*(.67f-.08f*q), elbowy=H*(.63f+.10f*q);seg(c,sx,sy,elbowx,elbowy,H*.032f,skin);seg(c,elbowx,elbowy,w*.69f,floor,H*.032f,skin);
            seg(c,hx,hy,w*.28f,H*.68f, H*.044f,shorts);seg(c,w*.28f,H*.68f,footx,floor,H*.035f,skin);shoe(c,footx,floor,-1);
        }
        private void kneePush(Canvas c,float w,float H,float q){
            float y=H*(.43f+.16f*q), sx=w*.66f, hx=w*.44f, floor=H*.84f;
            head(c,w*.74f,y-H*.04f,H*.04f);torso(c,sx,y,hx,y+H*.04f,H*.065f);
            float ex=w*(.66f-.08f*q), ey=H*(.64f+.09f*q);seg(c,sx,y,ex,ey,H*.032f,skin);seg(c,ex,ey,w*.69f,floor,H*.032f,skin);
            seg(c,hx,y+H*.04f,w*.35f,H*.72f,H*.044f,shorts);seg(c,w*.35f,H*.72f,w*.30f,floor,H*.038f,skin);
        }
        private void shoulderTap(Canvas c,float w,float H,float q){
            float y=H*.50f,sx=w*.64f,hx=w*.41f,floor=H*.84f;head(c,w*.72f,y-H*.05f,H*.04f);torso(c,sx,y,hx,y+H*.03f,H*.064f);
            seg(c,hx,y+H*.03f,w*.20f,floor,H*.04f,shorts);shoe(c,w*.18f,floor,-1);
            if(q<.5f){seg(c,sx,y,w*.68f,floor,H*.03f,skin);seg(c,sx-H*.02f,y+H*.02f,w*.60f,y-H*.035f,H*.03f,skin);}else{seg(c,sx-H*.02f,y,w*.60f,floor,H*.03f,skin);seg(c,sx+H*.02f,y+H*.02f,w*.69f,y-H*.03f,H*.03f,skin);}
        }
        private void plank(Canvas c,float w,float H,float q){
            float y=H*.55f;head(c,w*.73f,y-H*.045f,H*.04f);torso(c,w*.65f,y,w*.42f,y+H*.025f,H*.064f);seg(c,w*.42f,y+H*.025f,w*.18f,H*.84f,H*.04f,shorts);seg(c,w*.62f,y+H*.02f,w*.58f,H*.84f,H*.032f,skin);seg(c,w*.58f,H*.84f,w*.70f,H*.84f,H*.032f,skin);
        }
        private void mountainClimber(Canvas c,float w,float H,float q){
            float y=H*.50f;head(c,w*.74f,y-H*.045f,H*.04f);torso(c,w*.66f,y,w*.43f,y+H*.04f,H*.062f);seg(c,w*.65f,y,w*.69f,H*.84f,H*.03f,skin);
            float kx=(q<.5f?w*.48f:w*.28f), ky=(q<.5f?H*.70f:H*.77f);seg(c,w*.43f,y+H*.04f,kx,ky,H*.042f,shorts);seg(c,kx,ky,(q<.5f?w*.59f:w*.18f),H*.84f,H*.034f,skin);
            float k2x=(q<.5f?w*.28f:w*.48f), k2y=(q<.5f?H*.77f:H*.70f);seg(c,w*.40f,y+H*.05f,k2x,k2y,H*.038f,shorts);seg(c,k2x,k2y,(q<.5f?w*.18f:w*.59f),H*.84f,H*.032f,skin);
        }
        private void jumpingJack(Canvas c,float w,float H,float q){
            float cx=w*.5f, top=H*.24f;head(c,cx,top,H*.045f);torso(c,cx,top+H*.09f,cx,top+H*.34f,H*.075f);
            float spread=w*(.10f+.18f*q);float handY=top+H*(.23f-.27f*q);seg(c,cx-H*.03f,top+H*.10f,cx-spread,handY,H*.032f,skin);seg(c,cx+H*.03f,top+H*.10f,cx+spread,handY,H*.032f,skin);
            seg(c,cx-H*.03f,top+H*.34f,cx-spread*.70f,H*.66f,H*.044f,shorts);seg(c,cx-spread*.70f,H*.66f,cx-spread,H*.84f,H*.036f,skin);
            seg(c,cx+H*.03f,top+H*.34f,cx+spread*.70f,H*.66f,H*.044f,shorts);seg(c,cx+spread*.70f,H*.66f,cx+spread,H*.84f,H*.036f,skin);
        }
        private void highKnees(Canvas c,float w,float H,float q){standingBase(c,w,H,w*.5f,H*.24f,.2f,(q<.5f?q*2:(1-q)*2));}
        private void squat(Canvas c,float w,float H,float q){
            float cx=w*.5f, headY=H*(.25f+.14f*q), shoulderY=headY+H*.10f, hipY=H*(.53f+.12f*q);head(c,cx,headY,H*.045f);torso(c,cx,shoulderY,cx,hipY,H*.075f);
            seg(c,cx-H*.03f,shoulderY,cx-w*.18f,H*.48f,H*.032f,skin);seg(c,cx+H*.03f,shoulderY,cx+w*.18f,H*.48f,H*.032f,skin);
            seg(c,cx-H*.03f,hipY,cx-w*.15f,H*.69f,H*.045f,shorts);seg(c,cx-w*.15f,H*.69f,cx-w*.22f,H*.84f,H*.038f,skin);
            seg(c,cx+H*.03f,hipY,cx+w*.15f,H*.69f,H*.045f,shorts);seg(c,cx+w*.15f,H*.69f,cx+w*.22f,H*.84f,H*.038f,skin);
        }
        private void lunge(Canvas c,float w,float H,float q){
            float cx=w*.5f, y=H*(.25f+.10f*q), sh=y+H*.10f, hip=H*(.53f+.10f*q);head(c,cx,y,H*.045f);torso(c,cx,sh,cx,hip,H*.075f);
            seg(c,cx-H*.03f,sh,cx-w*.14f,H*.50f,H*.032f,skin);seg(c,cx+H*.03f,sh,cx+w*.14f,H*.50f,H*.032f,skin);
            seg(c,cx-H*.03f,hip,cx-w*.18f,H*.69f,H*.045f,shorts);seg(c,cx-w*.18f,H*.69f,cx-w*.29f,H*.84f,H*.038f,skin);
            seg(c,cx+H*.03f,hip,cx+w*.18f,H*(.68f+.08f*q),H*.045f,shorts);seg(c,cx+w*.18f,H*(.68f+.08f*q),cx+w*.30f,H*.84f,H*.038f,skin);
        }
        private void calfRaise(Canvas c,float w,float H,float q){
            float lift=H*.045f*q;standingBase(c,w,H,w*.5f,H*.24f-lift,0,0);
            p.setColor(Color.rgb(247,249,252));c.drawRect(0,H*.845f-lift,w,H*.90f,p); // clean old shoe baseline region
            shoe(c,w*.40f,H*.845f-lift,-1);shoe(c,w*.60f,H*.845f-lift,1);
        }
        private void wallSit(Canvas c,float w,float H,float q){
            p.setColor(Color.rgb(200,205,212));p.setStrokeWidth(8);c.drawLine(w*.30f,H*.20f,w*.30f,H*.88f,p);
            float x=w*.39f;head(c,x,H*.31f,H*.045f);torso(c,x,H*.40f,x,H*.61f,H*.072f);seg(c,x,H*.61f,w*.52f,H*.69f,H*.045f,shorts);seg(c,w*.52f,H*.69f,w*.52f,H*.84f,H*.038f,skin);seg(c,x,H*.47f,w*.56f,H*.51f,H*.032f,skin);
        }
        private void gluteBridge(Canvas c,float w,float H,float q){
            float floor=H*.84f, hipY=H*(.78f-.18f*q);head(c,w*.22f,H*.76f,H*.04f);torso(c,w*.29f,H*.75f,w*.47f,hipY,H*.062f);seg(c,w*.47f,hipY,w*.62f,H*.68f,H*.044f,shorts);seg(c,w*.62f,H*.68f,w*.72f,floor,H*.036f,skin);seg(c,w*.30f,H*.79f,w*.18f,floor,H*.03f,skin);
        }
        private void tricepDip(Canvas c,float w,float H,float q){
            float benchY=H*.63f;p.setColor(Color.rgb(145,150,158));c.drawRoundRect(w*.34f,benchY,w*.75f,benchY+H*.045f,12,12,p);c.drawRect(w*.38f,benchY,w*.41f,H*.85f,p);c.drawRect(w*.69f,benchY,w*.72f,H*.85f,p);
            float y=H*(.39f+.15f*q),sx=w*.47f,hipx=w*.49f,hipy=y+H*.23f;head(c,sx,y,H*.043f);torso(c,sx,y+H*.09f,hipx,hipy,H*.07f);seg(c,sx,y+H*.10f,w*.61f,benchY,H*.032f,skin);seg(c,hipx,hipy,w*.65f,H*.72f,H*.044f,shorts);seg(c,w*.65f,H*.72f,w*.78f,H*.84f,H*.036f,skin);
        }
        private void bentRow(Canvas c,float w,float H,float q){
            float sx=w*.53f, sy=H*.43f, hx=w*.42f, hy=H*.58f;head(c,w*.61f,H*.34f,H*.043f);torso(c,sx,sy,hx,hy,H*.07f);seg(c,hx,hy,w*.36f,H*.70f,H*.045f,shorts);seg(c,w*.36f,H*.70f,w*.31f,H*.84f,H*.037f,skin);seg(c,hx,hy,w*.54f,H*.70f,H*.045f,shorts);seg(c,w*.54f,H*.70f,w*.59f,H*.84f,H*.037f,skin);
            float handY=H*(.70f-.18f*q);seg(c,sx,sy,w*.42f,handY,H*.032f,skin);seg(c,sx,sy,w*.64f,handY,H*.032f,skin);dumbbell(c,w*.42f,handY,1);dumbbell(c,w*.64f,handY,1);
        }
        private void bicepCurl(Canvas c,float w,float H,float q){
            float cx=w*.5f, top=H*.25f;head(c,cx,top,H*.045f);torso(c,cx,top+H*.10f,cx,top+H*.35f,H*.075f);seg(c,cx-H*.03f,top+H*.12f,cx-w*.14f,top+H*.27f,H*.032f,skin);seg(c,cx+H*.03f,top+H*.12f,cx+w*.14f,top+H*.27f,H*.032f,skin);
            float fy=top+H*(.48f-.27f*q);seg(c,cx-w*.14f,top+H*.27f,cx-w*.16f,fy,H*.03f,skin);seg(c,cx+w*.14f,top+H*.27f,cx+w*.16f,fy,H*.03f,skin);dumbbell(c,cx-w*.16f,fy,1);dumbbell(c,cx+w*.16f,fy,1);
            seg(c,cx-H*.03f,top+H*.35f,cx-w*.08f,H*.84f,H*.04f,shorts);seg(c,cx+H*.03f,top+H*.35f,cx+w*.08f,H*.84f,H*.04f,shorts);
        }
        private void reverseFly(Canvas c,float w,float H,float q){
            float sx=w*.52f, sy=H*.43f, hx=w*.43f, hy=H*.58f;head(c,w*.60f,H*.34f,H*.043f);torso(c,sx,sy,hx,hy,H*.07f);seg(c,hx,hy,w*.36f,H*.84f,H*.04f,shorts);seg(c,hx,hy,w*.56f,H*.84f,H*.04f,shorts);
            float spread=w*(.07f+.18f*q);seg(c,sx,sy,sx-spread,H*(.60f-.18f*q),H*.03f,skin);seg(c,sx,sy,sx+spread,H*(.60f-.18f*q),H*.03f,skin);dumbbell(c,sx-spread,H*(.60f-.18f*q),.9f);dumbbell(c,sx+spread,H*(.60f-.18f*q),.9f);
        }
        private void superman(Canvas c,float w,float H,float q){
            float y=H*(.70f-.08f*q);head(c,w*.70f,y-H*.04f,H*.04f);torso(c,w*.62f,y,w*.44f,y+H*.02f,H*.06f);seg(c,w*.62f,y,w*.82f,y-H*.08f*q,H*.03f,skin);seg(c,w*.44f,y+H*.02f,w*.20f,y-H*.06f*q,H*.04f,shorts);
        }
        private void backHold(Canvas c,float w,float H,float q){
            float y=H*.67f;head(c,w*.70f,y-H*.075f,H*.04f);torso(c,w*.62f,y-H*.03f,w*.44f,y+H*.02f,H*.06f);seg(c,w*.44f,y+H*.02f,w*.22f,H*.84f,H*.04f,shorts);seg(c,w*.60f,y-H*.02f,w*.78f,y-H*.10f,H*.03f,skin);
        }
    }
}
