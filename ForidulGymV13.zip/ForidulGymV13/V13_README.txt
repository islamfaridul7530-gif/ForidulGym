FORIDUL GYM V13
All 18 exercise demonstrations use the upgraded filled human-style renderer.
Includes a 3-second countdown before exercise start.
