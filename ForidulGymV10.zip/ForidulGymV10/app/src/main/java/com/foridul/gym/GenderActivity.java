package com.foridul.gym;
import android.os.*;import android.content.*;
public class GenderActivity extends SetupBase{
 public void onCreate(Bundle b){super.onCreate(b);base("What's your gender?");
  Button f=choice("Female"),m=choice("Male"),o=choice("Other");
  f.setOnClickListener(v->go("Female"));m.setOnClickListener(v->go("Male"));o.setOnClickListener(v->go("Other"));
 } void go(String x){getSharedPreferences("gym_prefs",0).edit().putString("gender",x).apply();startActivity(new Intent(this,AgeActivity.class));}
}