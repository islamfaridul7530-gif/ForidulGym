package com.foridul.gym;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;

public class PlanActivity extends Activity {
    private LinearLayout list;
    private TextView progressText;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);

        LinearLayout outer=new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setBackgroundColor(Color.rgb(245,247,250));

        LinearLayout top=new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setPadding(28,24,28,18);
        top.setBackgroundColor(Color.WHITE);
        outer.addView(top,new LinearLayout.LayoutParams(-1,-2));

        TextView title=text("FORIDUL GYM",26,Color.rgb(25,25,25),true);
        top.addView(title);
        TextView sub=text("30 Day Workout Plan",15,Color.DKGRAY,false);
        top.addView(sub);

        progressText=text("",14,Color.rgb(65,65,65),false);
        progressText.setPadding(0,10,0,0);
        top.addView(progressText);

        ScrollView scroll=new ScrollView(this);
        list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(20,16,20,28);
        scroll.addView(list);
        outer.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        setContentView(outer);
        buildDays();
    }

    @Override protected void onResume(){
        super.onResume();
        updateProgress();
        if(list!=null) buildDays();
    }

    private void buildDays(){
        list.removeAllViews();
        int completed=getSharedPreferences("gym_prefs",MODE_PRIVATE).getInt("completed_day",0);
        for(int day=1;day<=30;day++){
            final int d=day;
            String type=WorkoutData.typeForDay(day);

            LinearLayout card=new LinearLayout(this);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setPadding(20,16,20,16);

            GradientDrawable bg=new GradientDrawable();
            bg.setColor(Color.WHITE);
            bg.setCornerRadius(22);
            card.setBackground(bg);

            TextView num=text(String.valueOf(day),20,Color.WHITE,true);
            num.setGravity(Gravity.CENTER);
            GradientDrawable circle=new GradientDrawable();
            if(day<=completed) circle.setColor(Color.rgb(57,190,114));
            else if("REST".equals(type)) circle.setColor(Color.rgb(140,145,155));
            else circle.setColor(Color.rgb(47,113,229));
            circle.setShape(GradientDrawable.OVAL);
            num.setBackground(circle);
            card.addView(num,new LinearLayout.LayoutParams(58,58));

            LinearLayout info=new LinearLayout(this);
            info.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams ilp=new LinearLayout.LayoutParams(0,-2,1);
            ilp.setMargins(16,0,8,0);
            card.addView(info,ilp);

            info.addView(text("Day "+day+" • "+WorkoutData.titleForDay(day),17,Color.rgb(30,30,30),true));
            String desc;
            if("REST".equals(type)) desc="Recovery • Stretch • Hydrate";
            else desc=WorkoutData.exercisesForDay(day).length+" exercises • "+WorkoutData.estimatedMinutes(day)+" min";
            info.addView(text(desc,13,Color.GRAY,false));

            TextView arrow=text(day<=completed?"✓":"›",24,
                    day<=completed?Color.rgb(57,190,114):Color.rgb(80,80,80),true);
            arrow.setGravity(Gravity.CENTER);
            card.addView(arrow,new LinearLayout.LayoutParams(44,58));

            card.setOnClickListener(v->{
                Intent i=new Intent(this,DayActivity.class);
                i.putExtra("day",d);
                startActivity(i);
            });

            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
            lp.setMargins(0,0,0,12);
            list.addView(card,lp);
        }
        updateProgress();
    }

    private void updateProgress(){
        int c=getSharedPreferences("gym_prefs",MODE_PRIVATE).getInt("completed_day",0);
        progressText.setText("Progress: "+c+" / 30 days completed");
    }

    private TextView text(String s,int sp,int color,boolean bold){
        TextView t=new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        if(bold)t.setTypeface(null,Typeface.BOLD);
        return t;
    }
}
