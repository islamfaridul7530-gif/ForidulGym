package com.foridul.gym;
import android.app.*; import android.content.*; import android.graphics.*; import android.graphics.drawable.*; import android.os.*; import android.view.*; import android.widget.*;

public class MainActivity extends Activity {
 LinearLayout root; int day;
 public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.WHITE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
  ScrollView sc=new ScrollView(this);sc.setBackgroundColor(Color.rgb(248,249,252));root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(28,38,28,35);sc.addView(root);setContentView(sc);}
 protected void onResume(){super.onResume(); if(root!=null) build();}
 void build(){root.removeAllViews();int done=getSharedPreferences("gym_prefs",0).getInt("completed_day",0);day=Math.min(30,done+1);
  root.addView(tx("FORIDUL GYM",30,Color.rgb(20,20,22),true));
  TextView sub=tx("30 Days Fitness Challenge",18,Color.DKGRAY,false);sub.setPadding(0,3,0,25);root.addView(sub);
  LinearLayout goal=card(Color.WHITE);goal.addView(tx("Weekly Goal",20,Color.BLACK,true));TextView pr=tx(done+"/30 days completed",14,Color.GRAY,false);pr.setPadding(0,7,0,12);goal.addView(pr);
  ProgressBar pb=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);pb.setMax(30);pb.setProgress(done);goal.addView(pb,new LinearLayout.LayoutParams(-1,16));
  TextView mot=tx(done==0?"Start today and build your consistency.":"Keep going! Every workout takes you closer to your goal.",14,Color.DKGRAY,false);mot.setPadding(0,14,0,0);goal.addView(mot);root.addView(goal,lp(0,0,0,28));
  TextView dc=tx("Daily Challenge",24,Color.BLACK,true);dc.setPadding(0,0,0,12);root.addView(dc);
  LinearLayout hero=card(Color.rgb(45,112,230));hero.addView(tx("TODAY'S WORKOUT",13,Color.rgb(225,235,255),true));TextView title=tx("Day "+day+" • "+WorkoutData.titleForDay(day),27,Color.WHITE,true);title.setPadding(0,10,0,5);hero.addView(title);
  String d="REST".equals(WorkoutData.typeForDay(day))?"Recovery • Stretch • Hydrate":WorkoutData.exercisesForDay(day).length+" exercises  •  "+WorkoutData.estimatedMinutes(day)+" min";
  TextView info=tx(d,15,Color.rgb(230,238,255),false);info.setPadding(0,0,0,18);hero.addView(info);Button st=btn("START",true);hero.addView(st);st.setOnClickListener(v->openDay(day));root.addView(hero,lp(0,0,0,28));
  root.addView(tx("30 Day Plan",22,Color.BLACK,true));LinearLayout pc=card(Color.WHITE);pc.addView(tx("View all workouts from Day 1 to Day 30",15,Color.DKGRAY,false));Button view=btn("VIEW FULL PLAN",false);pc.addView(view,lp(0,14,0,0));view.setOnClickListener(v->startActivity(new Intent(this,PlanActivity.class)));root.addView(pc,lp(0,12,0,22));
 }
 void openDay(int d){Intent i=new Intent(this,DayActivity.class);i.putExtra("day",d);startActivity(i);}
 LinearLayout card(int c){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setPadding(22,20,22,20);GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(28);x.setBackground(g);return x;}
 Button btn(String s,boolean white){Button b=new Button(this);b.setText(s);b.setTextSize(15);b.setTextColor(white?Color.BLACK:Color.WHITE);GradientDrawable g=new GradientDrawable();g.setColor(white?Color.WHITE:Color.rgb(45,112,230));g.setCornerRadius(50);b.setBackground(g);b.setMinHeight(56);return b;}
 TextView tx(String s,int z,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
 LinearLayout.LayoutParams lp(int l,int t,int r,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(l,t,r,b);return p;}
}