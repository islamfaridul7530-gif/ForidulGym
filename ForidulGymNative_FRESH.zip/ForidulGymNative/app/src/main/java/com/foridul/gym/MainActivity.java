package com.foridul.gym;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private LinearLayout root;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.parseColor("#0B0F14"));
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(20), dp(18), dp(30));
        scroll.addView(root);
        addText("FORIDUL GYM", 28, "#12D69B", true);
        addText("Native Android • Offline Ready", 15, "#A7B0BE", false);
        section("Quick Start");
        button("Start Workout", v -> toast("Workout started"));
        section("Workout Routines");
        button("Push Day", v -> toast("Chest, Shoulders & Triceps"));
        button("Pull Day", v -> toast("Back & Biceps"));
        button("Leg Day", v -> toast("Quads, Hamstrings & Calves"));
        section("BMI Calculator");
        EditText weight = input("Weight (kg)");
        EditText height = input("Height (cm)");
        button("Calculate BMI", v -> {
            try {
                double w = Double.parseDouble(weight.getText().toString());
                double h = Double.parseDouble(height.getText().toString()) / 100.0;
                double bmi = w / (h*h);
                toast(String.format("BMI: %.1f", bmi));
            } catch (Exception e) { toast("Enter valid numbers"); }
        });
        section("Progress");
        addText("Workouts completed: 0", 16, "#FFFFFF", false);
        addText("This week: 0 sessions", 16, "#FFFFFF", false);
        setContentView(scroll);
    }
    private void section(String s){ addText(s,20,"#FFFFFF",true); }
    private void addText(String s,int size,String c,boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.parseColor(c));
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setPadding(0,dp(8),0,dp(8)); root.addView(t);
    }
    private void button(String s, View.OnClickListener l){
        Button b=new Button(this); b.setText(s); b.setAllCaps(false); b.setTextSize(16); b.setOnClickListener(l);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(54)); p.setMargins(0,0,0,dp(10)); root.addView(b,p);
    }
    private EditText input(String h){
        EditText e=new EditText(this); e.setHint(h); e.setSingleLine(true); e.setTextColor(Color.WHITE); e.setHintTextColor(Color.GRAY);
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(52)); p.setMargins(0,0,0,dp(10)); root.addView(e,p); return e;
    }
    private int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    private void toast(String s){ Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }
}
