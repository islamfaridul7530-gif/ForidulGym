package com.foridul.gym;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private LinearLayout root;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.parseColor("#0B0F14"));
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(20), dp(18), dp(30));
        scroll.addView(root);

        addTitle("FORIDUL GYM");
        addSub("Native Android • Offline Ready");
        addSection("Quick Start");
        addButton("Start Workout", v -> openWorkout("Full Body"));
        addSection("Workout Routines");
        addButton("Push Day", v -> openWorkout("Push Day"));
        addButton("Pull Day", v -> openWorkout("Pull Day"));
        addButton("Leg Day", v -> openWorkout("Leg Day"));

        addSection("BMI Calculator");
        final EditText weight = input("Weight (kg)");
        final EditText height = input("Height (cm)");
        addButton("Calculate BMI", v -> {
            try {
                double w = Double.parseDouble(weight.getText().toString().trim());
                double hcm = Double.parseDouble(height.getText().toString().trim());
                double hm = hcm / 100.0;
                double bmi = w / (hm * hm);
                String c = bmi < 18.5 ? "Underweight" : bmi < 25 ? "Normal" : bmi < 30 ? "Overweight" : "Obesity";
                toast(String.format("BMI: %.1f • %s", bmi, c));
            } catch (Exception e) { toast("Enter valid weight and height"); }
        });

        addSection("Progress");
        addCard("Workouts completed: 0");
        addCard("This week: 0 sessions");
        setContentView(scroll);
    }

    private void openWorkout(String type) {
        Intent i = new Intent(this, WorkoutActivity.class);
        i.putExtra("workout_type", type);
        startActivity(i);
    }
    private void addTitle(String t){ TextView v=new TextView(this); v.setText(t); v.setTextColor(Color.parseColor("#12D69B")); v.setTextSize(28); v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); root.addView(v); }
    private void addSub(String t){ TextView v=new TextView(this); v.setText(t); v.setTextColor(Color.parseColor("#A7B0BE")); v.setTextSize(15); v.setPadding(0,dp(4),0,dp(18)); root.addView(v); }
    private void addSection(String t){ TextView v=new TextView(this); v.setText(t); v.setTextColor(Color.WHITE); v.setTextSize(20); v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); v.setPadding(0,dp(18),0,dp(10)); root.addView(v); }
    private void addButton(String t, View.OnClickListener l){ Button b=new Button(this); b.setText(t); b.setTextSize(16); b.setAllCaps(false); b.setTextColor(Color.BLACK); b.setBackgroundColor(Color.parseColor("#12D69B")); b.setOnClickListener(l); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(54)); p.setMargins(0,0,0,dp(10)); root.addView(b,p); }
    private EditText input(String h){ EditText e=new EditText(this); e.setHint(h); e.setHintTextColor(Color.parseColor("#7E8897")); e.setTextColor(Color.WHITE); e.setSingleLine(true); e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL); e.setPadding(dp(14),0,dp(14),0); e.setBackgroundColor(Color.parseColor("#17202B")); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(52)); p.setMargins(0,0,0,dp(10)); root.addView(e,p); return e; }
    private void addCard(String t){ TextView v=new TextView(this); v.setText(t); v.setTextColor(Color.WHITE); v.setTextSize(16); v.setGravity(Gravity.CENTER_VERTICAL); v.setPadding(dp(14),0,dp(14),0); v.setBackgroundColor(Color.parseColor("#17202B")); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(52)); p.setMargins(0,0,0,dp(10)); root.addView(v,p); }
    private int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    private void toast(String s){ Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }
}
