package com.foridul.gym;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.*;
import android.os.CountDownTimer;

public class WorkoutActivity extends Activity {
    private LinearLayout root;
    private TextView timerText;
    private CountDownTimer timer;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.parseColor("#0B0F14"));
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(20), dp(18), dp(30));
        scroll.addView(root);

        String type = getIntent().getStringExtra("workout_type");
        if (type == null) type = "Full Body";
        addTitle(type.toUpperCase());
        addText("Complete each exercise and tick Completed.");

        if ("Push Day".equals(type)) {
            addExercise("Push Ups","3 Sets × 12 Reps");
            addExercise("Shoulder Press","3 Sets × 10 Reps");
            addExercise("Tricep Dips","3 Sets × 10 Reps");
        } else if ("Pull Day".equals(type)) {
            addExercise("Bent Over Row","3 Sets × 12 Reps");
            addExercise("Bicep Curls","3 Sets × 12 Reps");
            addExercise("Reverse Fly","3 Sets × 12 Reps");
        } else if ("Leg Day".equals(type)) {
            addExercise("Squats","3 Sets × 15 Reps");
            addExercise("Lunges","3 Sets × 12 Reps");
            addExercise("Calf Raises","3 Sets × 20 Reps");
        } else {
            addExercise("Push Ups","3 Sets × 12 Reps");
            addExercise("Squats","3 Sets × 15 Reps");
            addExercise("Shoulder Press","3 Sets × 10 Reps");
            addExercise("Bicep Curls","3 Sets × 12 Reps");
            addExercise("Plank","3 Sets × 30 Seconds");
        }

        addTimer();

        Button finish = new Button(this);
        finish.setText("Finish Workout");
        finish.setTextSize(16);
        finish.setAllCaps(false);
        finish.setTextColor(Color.BLACK);
        finish.setBackgroundColor(Color.parseColor("#12D69B"));
        finish.setOnClickListener(v -> { Toast.makeText(this,"Workout completed!",Toast.LENGTH_LONG).show(); finish(); });
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(55));
        p.setMargins(0, dp(20), 0, dp(10));
        root.addView(finish,p);
        setContentView(scroll);
    }

    private void addExercise(String n,String r){
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(15),dp(12),dp(15),dp(12)); c.setBackgroundColor(Color.parseColor("#17202B"));
        TextView t=new TextView(this); t.setText(n); t.setTextColor(Color.WHITE); t.setTextSize(18); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        TextView i=new TextView(this); i.setText(r); i.setTextColor(Color.parseColor("#A7B0BE")); i.setTextSize(14); i.setPadding(0,dp(5),0,dp(8));
        CheckBox cb=new CheckBox(this); cb.setText("Completed"); cb.setTextColor(Color.parseColor("#12D69B"));
        c.addView(t); c.addView(i); c.addView(cb);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,0,0,dp(12)); root.addView(c,p);
    }

    private void addTimer(){
        TextView h=new TextView(this); h.setText("REST TIMER"); h.setTextColor(Color.WHITE); h.setTextSize(20); h.setTypeface(Typeface.DEFAULT,Typeface.BOLD); h.setPadding(0,dp(15),0,dp(10)); root.addView(h);
        timerText=new TextView(this); timerText.setText("01:00"); timerText.setTextColor(Color.parseColor("#12D69B")); timerText.setTextSize(34); timerText.setGravity(Gravity.CENTER); root.addView(timerText);
        Button b=new Button(this); b.setText("Start 60 Sec Rest"); b.setAllCaps(false); b.setOnClickListener(v -> startRestTimer()); root.addView(b);
    }

    private void startRestTimer(){
        if(timer!=null) timer.cancel();
        timer=new CountDownTimer(60000,1000){
            public void onTick(long m){ timerText.setText(String.format("00:%02d",m/1000)); }
            public void onFinish(){ timerText.setText("00:00"); Toast.makeText(WorkoutActivity.this,"Rest finished!",Toast.LENGTH_SHORT).show(); }
        }.start();
    }

    private void addTitle(String t){ TextView v=new TextView(this); v.setText(t); v.setTextColor(Color.parseColor("#12D69B")); v.setTextSize(27); v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); root.addView(v); }
    private void addText(String t){ TextView v=new TextView(this); v.setText(t); v.setTextColor(Color.parseColor("#A7B0BE")); v.setTextSize(15); v.setPadding(0,dp(5),0,dp(20)); root.addView(v); }
    private int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    @Override protected void onDestroy(){ if(timer!=null) timer.cancel(); super.onDestroy(); }
}
