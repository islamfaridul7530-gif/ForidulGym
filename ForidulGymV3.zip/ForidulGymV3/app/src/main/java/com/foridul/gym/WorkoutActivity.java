package com.foridul.gym;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.*;

public class WorkoutActivity extends Activity {
    private LinearLayout root;
    private TextView timerText;
    private CountDownTimer timer;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        String type=getIntent().getStringExtra("workout_type");
        if(type==null)type="Workout";

        ScrollView scroll=new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(11,16,22));
        root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(34,24,34,40);
        scroll.addView(root);

        title(type);
        if("Pull Day".equals(type)) {
            ex("Bent Over Row","3 Sets × 12 Reps");
            ex("Bicep Curls","3 Sets × 12 Reps");
            ex("Reverse Fly","3 Sets × 12 Reps");
        } else {
            ex("Squats","3 Sets × 15 Reps");
            ex("Lunges","3 Sets × 12 Reps");
            ex("Calf Raises","3 Sets × 20 Reps");
        }

        title("REST TIMER");
        timerText=title("01:00");
        Button rest=btn("Start 60 Sec Rest");
        rest.setOnClickListener(v -> startRest());

        Button finish=btn("Finish Workout");
        finish.setOnClickListener(v -> {
            int c=getSharedPreferences("gym_prefs",MODE_PRIVATE).getInt("workouts_completed",0)+1;
            getSharedPreferences("gym_prefs",MODE_PRIVATE).edit().putInt("workouts_completed",c).apply();
            Toast.makeText(this,"Workout completed!",Toast.LENGTH_SHORT).show();
            finish();
        });

        setContentView(scroll);
    }

    private void startRest() {
        if(timer!=null)timer.cancel();
        timer=new CountDownTimer(60000,1000) {
            public void onTick(long ms){ timerText.setText(String.format("00:%02d",ms/1000)); }
            public void onFinish(){ timerText.setText("00:00"); }
        }.start();
    }

    private void ex(String n,String d){
        TextView t=title(n); t.setTextSize(24);
        TextView x=title(d); x.setTextSize(19); x.setTextColor(Color.LTGRAY);
        CheckBox cb=new CheckBox(this); cb.setText("Completed"); cb.setTextColor(Color.rgb(20,210,160)); cb.setTextSize(18); root.addView(cb);
    }

    private TextView title(String s){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(30); t.setTextColor(Color.WHITE);
        t.setTypeface(null,android.graphics.Typeface.BOLD); t.setPadding(0,12,0,10); root.addView(t); return t;
    }

    private Button btn(String s){
        Button b=new Button(this); b.setText(s); b.setTextSize(20); b.setBackgroundColor(Color.rgb(20,210,160));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,100); lp.setMargins(0,8,0,10); root.addView(b,lp); return b;
    }
}
