package com.foridul.gym;

import android.app.Activity;
import android.graphics.*;
import android.os.*;
import android.speech.tts.TextToSpeech;
import android.view.*;
import android.widget.*;
import java.util.Locale;

public class PushUpActivity extends Activity implements TextToSpeech.OnInitListener {
    private TextToSpeech tts;
    private TextView timerText,repsText,statusText;
    private PushUpView anim;
    private CountDownTimer timer;
    private final Handler h=new Handler(Looper.getMainLooper());
    private boolean running=false;
    private int reps=0;

    private final Runnable repLoop=new Runnable(){
        @Override public void run(){
            if(!running)return;
            reps++;
            repsText.setText("Reps: "+reps+" / 12");
            if(reps==6)speak("Halfway. Keep going.");
            if(reps==10)speak("Two more reps.");
            if(reps>=12){
                running=false; anim.setRunning(false);
                statusText.setText("Set completed • Rest 60 seconds");
                speak("Set completed. Rest for 60 seconds.");
                startRest();
                return;
            }
            h.postDelayed(this,1800);
        }
    };

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        tts=new TextToSpeech(this,this);

        ScrollView scroll=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28,18,28,28);
        root.setBackgroundColor(Color.WHITE);
        scroll.addView(root);

        TextView title=txt("PUSH UPS",30,Color.BLACK,true); title.setGravity(Gravity.CENTER); root.addView(title);
        TextView sub=txt("3 Sets × 12 Reps",20,Color.DKGRAY,false); sub.setGravity(Gravity.CENTER); root.addView(sub);
        statusText=txt("Get ready",18,Color.DKGRAY,false); statusText.setGravity(Gravity.CENTER); statusText.setPadding(0,10,0,10); root.addView(statusText);

        anim=new PushUpView(this);
        root.addView(anim,new LinearLayout.LayoutParams(-1,520));

        timerText=txt("00:30",52,Color.BLACK,true); timerText.setGravity(Gravity.CENTER); root.addView(timerText);
        repsText=txt("Reps: 0 / 12",26,Color.BLACK,true); repsText.setGravity(Gravity.CENTER); root.addView(repsText);

        Button start=btn("START SET"); root.addView(start); start.setOnClickListener(v->startSet());
        Button next=btn("NEXT EXERCISE"); root.addView(next); next.setOnClickListener(v->Toast.makeText(this,"Next exercise coming in next update",Toast.LENGTH_SHORT).show());
        Button finish=btn("FINISH WORKOUT"); root.addView(finish); finish.setOnClickListener(v->finishWorkout());

        setContentView(scroll);
    }

    private void startSet(){
        if(running)return;
        reps=0; repsText.setText("Reps: 0 / 12"); statusText.setText("Push-up set running");
        running=true; anim.setRunning(true);
        speak("Get ready. Start push ups.");
        if(timer!=null)timer.cancel();
        timer=new CountDownTimer(30000,1000){
            public void onTick(long ms){timerText.setText(String.format(Locale.US,"00:%02d",ms/1000));}
            public void onFinish(){timerText.setText("00:00");}
        }.start();
        h.removeCallbacks(repLoop);
        h.postDelayed(repLoop,1500);
    }

    private void startRest(){
        if(timer!=null)timer.cancel();
        timer=new CountDownTimer(60000,1000){
            public void onTick(long ms){timerText.setText(String.format(Locale.US,"00:%02d",ms/1000));}
            public void onFinish(){timerText.setText("00:00"); statusText.setText("Rest finished • Ready"); speak("Rest finished. Ready for the next set.");}
        }.start();
    }

    private void finishWorkout(){
        int c=getSharedPreferences("gym_prefs",MODE_PRIVATE).getInt("workouts_completed",0)+1;
        getSharedPreferences("gym_prefs",MODE_PRIVATE).edit().putInt("workouts_completed",c).apply();
        speak("Workout completed. Great job.");
        Toast.makeText(this,"Workout completed!",Toast.LENGTH_SHORT).show();
        finish();
    }

    private void speak(String s){ if(tts!=null)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"gym"); }

    @Override public void onInit(int status){
        if(status==TextToSpeech.SUCCESS){
            tts.setLanguage(Locale.US); tts.setSpeechRate(0.92f);
            speak("Welcome to Foridul Gym. Get ready for push ups.");
        }
    }

    @Override protected void onDestroy(){
        running=false; h.removeCallbacks(repLoop);
        if(timer!=null)timer.cancel();
        if(tts!=null){tts.stop();tts.shutdown();}
        super.onDestroy();
    }

    private TextView txt(String s,int sp,int color,boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        if(bold)t.setTypeface(null,Typeface.BOLD); return t;
    }

    private Button btn(String s){
        Button b=new Button(this); b.setText(s); b.setTextSize(19); b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.rgb(34,82,220));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,92); lp.setMargins(0,8,0,8); b.setLayoutParams(lp); return b;
    }

    public static class PushUpView extends View{
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Handler h=new Handler(Looper.getMainLooper());
        private boolean running=false; private float phase=0f;

        private final Runnable r=new Runnable(){
            @Override public void run(){
                if(!running)return;
                phase+=0.08f; if(phase>1f)phase=0f;
                invalidate(); h.postDelayed(this,50);
            }
        };

        public PushUpView(android.content.Context c){super(c); p.setStrokeCap(Paint.Cap.ROUND);}
        public void setRunning(boolean x){running=x; h.removeCallbacks(r); if(x)h.post(r); invalidate();}

        @Override protected void onDraw(Canvas c){
            super.onDraw(c); c.drawColor(Color.rgb(248,248,248));
            float w=getWidth(),hh=getHeight();
            p.setColor(Color.LTGRAY); p.setStrokeWidth(5); c.drawLine(w*.08f,hh*.82f,w*.92f,hh*.82f,p);

            float cyc=(float)((1-Math.cos(phase*2*Math.PI))/2.0);
            float y=hh*(.42f+.18f*cyc);
            float shoulderX=w*.60f, shoulderY=y;
            float hipX=w*.38f, hipY=y+hh*.02f;
            float footX=w*.18f, footY=hh*.78f;
            float handX=w*.66f, handY=hh*.79f;
            float headX=w*.70f, headY=y-hh*.08f;

            p.setColor(Color.rgb(35,110,220)); p.setStrokeWidth(25); c.drawLine(shoulderX,shoulderY,hipX,hipY,p);
            p.setColor(Color.rgb(245,180,145)); p.setStrokeWidth(14); c.drawLine(shoulderX,shoulderY,handX,handY,p);
            p.setColor(Color.rgb(35,35,35)); p.setStrokeWidth(17); c.drawLine(hipX,hipY,footX,footY,p);
            p.setColor(Color.rgb(245,180,145)); c.drawCircle(headX,headY,hh*.055f,p);
            p.setColor(Color.BLACK); p.setStrokeWidth(8); c.drawLine(footX,footY,footX-w*.05f,footY,p);

            p.setColor(Color.rgb(34,82,220)); p.setTextSize(38); p.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawText(running?"PUSH UP • KEEP GOING":"PRESS START",w*.18f,hh*.15f,p);
        }
    }
}
