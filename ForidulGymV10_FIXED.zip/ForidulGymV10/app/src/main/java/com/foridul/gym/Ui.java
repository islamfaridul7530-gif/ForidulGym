package com.foridul.gym;
import android.app.*; import android.graphics.*; import android.graphics.drawable.*; import android.view.*; import android.widget.*; import android.content.*;
public final class Ui{
 public static int blue(){return Color.rgb(45,105,225);}
 public static void safe(Activity a, View v,int l,int top,int r,int b){int id=a.getResources().getIdentifier("status_bar_height","dimen","android");int h=id>0?a.getResources().getDimensionPixelSize(id):0;v.setPadding(l,h+top,r,b);}
 public static TextView text(Context c,String s,int z,int col,boolean bold){TextView t=new TextView(c);t.setText(s);t.setTextSize(z);t.setTextColor(col);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
 public static Button button(Context c,String s){Button b=new Button(c);b.setText(s);b.setTextSize(15);b.setTextColor(Color.WHITE);GradientDrawable g=new GradientDrawable();g.setColor(blue());g.setCornerRadius(48);b.setBackground(g);b.setMinHeight(58);return b;}
 public static LinearLayout card(Context c){LinearLayout x=new LinearLayout(c);x.setOrientation(LinearLayout.VERTICAL);x.setPadding(22,20,22,20);GradientDrawable g=new GradientDrawable();g.setColor(Color.WHITE);g.setCornerRadius(28);x.setBackground(g);return x;}
 public static LinearLayout nav(Activity a,String selected){
  LinearLayout n=new LinearLayout(a);n.setOrientation(LinearLayout.HORIZONTAL);n.setGravity(Gravity.CENTER);n.setPadding(6,8,6,8);n.setBackgroundColor(Color.WHITE);
  String[] names={"Training","Reports","Me"}; Class<?>[] cls={MainActivity.class,ReportsActivity.class,MeActivity.class};
  for(int i=0;i<3;i++){final Class<?> c=cls[i];TextView t=text(a,names[i],14,names[i].equals(selected)?blue():Color.GRAY,names[i].equals(selected));t.setGravity(Gravity.CENTER);t.setPadding(4,12,4,12);n.addView(t,new LinearLayout.LayoutParams(0,-2,1));t.setOnClickListener(v->{if(!a.getClass().equals(c)){a.startActivity(new Intent(a,c));a.finish();}});}
  return n;
 }
}