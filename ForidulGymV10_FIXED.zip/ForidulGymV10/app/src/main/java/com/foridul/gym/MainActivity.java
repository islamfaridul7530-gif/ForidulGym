package com.foridul.gym;
import android.app.*;import android.content.*;import android.graphics.*;import android.graphics.drawable.*;import android.os.*;import android.view.*;import android.widget.*;
public class MainActivity extends Activity{
 LinearLayout root;int day;String goal;
 public void onCreate(Bundle b){super.onCreate(b);if(!getSharedPreferences("gym_prefs",0).getBoolean("setup_complete",false)){startActivity(new Intent(this,GenderActivity.class));finish();return;}getWindow().setStatusBarColor(Color.WHITE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
  LinearLayout shell=new LinearLayout(this);shell.setOrientation(LinearLayout.VERTICAL);ScrollView sc=new ScrollView(this);sc.setBackgroundColor(Color.rgb(248,249,252));root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);Ui.safe(this,root,28,18,28,30);sc.addView(root);shell.addView(sc,new LinearLayout.LayoutParams(-1,0,1));shell.addView(Ui.nav(this,"Training"));setContentView(shell);}
 protected void onResume(){super.onResume();if(root!=null)build();}
 void build(){root.removeAllViews();int done=getSharedPreferences("gym_prefs",0).getInt("completed_day",0);goal=getSharedPreferences("gym_prefs",0).getString("goal","GAIN");day=Math.min(30,done+1);
  root.addView(Ui.text(this,"FORIDUL GYM",30,Color.rgb(20,20,22),true));TextView sub=Ui.text(this,"GAIN".equals(goal)?"Muscle Gain • 30 Day Challenge":"Weight Loss • 30 Day Challenge",17,Color.DKGRAY,false);sub.setPadding(0,4,0,24);root.addView(sub);
  LinearLayout c=Ui.card(this);c.addView(Ui.text(this,"Weekly Goal",20,Color.BLACK,true));c.addView(Ui.text(this,done+"/30 days completed",14,Color.GRAY,false));ProgressBar pb=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);pb.setMax(30);pb.setProgress(done);c.addView(pb,new LinearLayout.LayoutParams(-1,16));root.addView(c,lp(0,0,0,26));
  LinearLayout hero=Ui.card(this);hero.setBackgroundColor(Ui.blue());hero.addView(Ui.text(this,"TODAY'S WORKOUT",13,Color.WHITE,true));hero.addView(Ui.text(this,"Day "+day+" • "+WorkoutData.titleForDay(day),27,Color.WHITE,true));String[][] ex=WorkoutData.exercisesForDay(day,goal);hero.addView(Ui.text(this,"REST".equals(WorkoutData.typeForDay(day))?"Recovery Day":ex.length+" exercises • "+WorkoutData.estimatedMinutes(day)+" min",15,Color.WHITE,false));Button st=Ui.button(this,"START");hero.addView(st);st.setOnClickListener(v->open(day));root.addView(hero,lp(0,0,0,25));
  root.addView(Ui.text(this,"30 Day Plan",22,Color.BLACK,true));Button plan=Ui.button(this,"VIEW FULL PLAN");root.addView(plan,lp(0,12,0,0));plan.setOnClickListener(v->startActivity(new Intent(this,PlanActivity.class)));
 }
 void open(int d){Intent i=new Intent(this,DayActivity.class);i.putExtra("day",d);startActivity(i);}
 LinearLayout.LayoutParams lp(int l,int t,int r,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(l,t,r,b);return p;}
}