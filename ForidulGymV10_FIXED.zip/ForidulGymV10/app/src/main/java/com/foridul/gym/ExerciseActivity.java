package com.foridul.gym;

import android.app.Activity;
import android.graphics.*;
import android.media.MediaPlayer;
import android.os.*;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.Locale;

public class ExerciseActivity extends Activity implements TextToSpeech.OnInitListener {
    private int day,index,target;
    private String[][] exercises;
    private String name,mode;
    private TextToSpeech tts;
    private MediaPlayer music;
    private boolean musicOn=true,running=false;
    private TextView count,status,nextLabel;
    private ExerciseView anim;
    private CountDownTimer timer;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private int current=0;

    private final Runnable repRunner=new Runnable(){
        @Override public void run(){
            if(!running)return;
            current++;
            count.setText(current+" / "+target);
            speakNumber(current);
            if(current>=target){
                running=false; 
                status.setText("Completed");
                speak("Exercise completed. Great job.");
                nextLabel.setText(index<exercises.length-1?"NEXT EXERCISE":"FINISH DAY");
                return;
            }
            handler.postDelayed(this,1800);
        }
    };

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        day=getIntent().getIntExtra("day",1);
        index=getIntent().getIntExtra("index",0);
        String goal=getSharedPreferences("gym_prefs",0).getString("goal","GAIN");
        exercises=WorkoutData.exercisesForDay(day,goal);
        if(exercises.length==0){ finish(); return; }
        if(index<0||index>=exercises.length)index=0;
        name=exercises[index][0];
        target=Integer.parseInt(exercises[index][1]);
        mode=exercises[index][2];

        tts=new TextToSpeech(this,this);
        music=MediaPlayer.create(this,R.raw.workout_music);
        if(music!=null){music.setLooping(true);music.setVolume(.14f,.14f);}

        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        Ui.safe(this,root,22,18,22,24);
        root.setBackgroundColor(Color.WHITE);

        TextView title=text(name.toUpperCase(),23,Color.rgb(30,30,30),true);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        String subtitle="time".equals(mode)?target+" Seconds":"Target "+target+" Reps";
        TextView sub=text(subtitle,14,Color.GRAY,false);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub);

        status=text("Get ready",14,Color.DKGRAY,false);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0,8,0,8);
        root.addView(status);

        anim=new ExerciseView(this,name);
        TextView form=text("Follow the exercise name and voice coach.\nRealistic movement animation will be added in the next animation update.",16,Color.DKGRAY,false); form.setGravity(Gravity.CENTER); form.setPadding(18,50,18,50); root.addView(form,new LinearLayout.LayoutParams(-1,0,1));

        count=text("0 / "+target,38,Color.rgb(32,32,32),true);
        count.setGravity(Gravity.CENTER);
        root.addView(count);

        Button start=button("START");
        root.addView(start);
        start.setOnClickListener(v->startExercise());

        LinearLayout controls=new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        Button musicBtn=button("MUSIC ON");
        Button next=button(index<exercises.length-1?"NEXT EXERCISE":"FINISH DAY");
        nextLabel=next;
        LinearLayout.LayoutParams half=new LinearLayout.LayoutParams(0,-2,1);
        half.setMargins(4,6,4,0);
        controls.addView(musicBtn,half);
        controls.addView(next,new LinearLayout.LayoutParams(0,-2,1));
        root.addView(controls);

        musicBtn.setOnClickListener(v->{
            musicOn=!musicOn;
            musicBtn.setText(musicOn?"MUSIC ON":"MUSIC OFF");
            if(music!=null){
                if(musicOn&&!music.isPlaying())music.start();
                else if(!musicOn&&music.isPlaying())music.pause();
            }
        });
        next.setOnClickListener(v->goNext());

        setContentView(root);
    }

    private void startExercise(){
        if(running)return;
        current=0;
        count.setText("0 / "+target);
        status.setText("Exercise running");
        running=true;
        
        if(musicOn&&music!=null&&!music.isPlaying())music.start();
        speak("Get ready. Start "+name+".");

        if("time".equals(mode)){
            if(timer!=null)timer.cancel();
            timer=new CountDownTimer(target*1000L,1000){
                public void onTick(long ms){
                    current=(int)(target-ms/1000L);
                    int left=(int)Math.ceil(ms/1000.0);
                    count.setText(left+" sec");
                    if(left==10)speak("Ten seconds left.");
                }
                public void onFinish(){
                    running=false;
                    count.setText("0 sec");
                    status.setText("Completed");
                    speak("Exercise completed.");
                    nextLabel.setText(index<exercises.length-1?"NEXT EXERCISE":"FINISH DAY");
                }
            }.start();
        }else{
            handler.removeCallbacks(repRunner);
            handler.postDelayed(repRunner,1200);
        }
    }

    private void speakNumber(int n){
        if(n<=12 || n==target) speak(String.valueOf(n));
        else if(n==target-2) speak("Two more.");
    }

    private void goNext(){
        running=false;
        handler.removeCallbacks(repRunner);
        if(timer!=null)timer.cancel();

        if(index<exercises.length-1){
            getIntent().putExtra("index",index+1);
            recreateWithIndex(index+1);
        }else{
            int old=getSharedPreferences("gym_prefs",MODE_PRIVATE).getInt("completed_day",0);
            if(day>old)getSharedPreferences("gym_prefs",MODE_PRIVATE).edit().putInt("completed_day",day).apply();
            speak("Day "+day+" completed. Excellent work.");
            Toast.makeText(this,"Day "+day+" completed!",Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void recreateWithIndex(int newIndex){
        android.content.Intent i=new android.content.Intent(this,ExerciseActivity.class);
        i.putExtra("day",day); i.putExtra("index",newIndex);
        startActivity(i); finish();
    }

    private void speak(String s){
        if(tts!=null)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"gymvoice");
    }

    @Override public void onInit(int statusCode){
        if(statusCode==TextToSpeech.SUCCESS){
            tts.setLanguage(Locale.US);
            tts.setSpeechRate(.94f);
            speak(name+". Get ready.");
        }
    }

    @Override protected void onDestroy(){
        running=false;
        handler.removeCallbacks(repRunner);
        if(timer!=null)timer.cancel();
        if(music!=null){try{music.stop();}catch(Exception ignored){} music.release();}
        if(tts!=null){tts.stop();tts.shutdown();}
        super.onDestroy();
    }

    private Button button(String s){
        Button b=new Button(this);
        b.setText(s);b.setTextSize(14);b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.rgb(47,113,229));
        b.setMinHeight(52);b.setPadding(10,8,10,8);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.setMargins(0,6,0,0); b.setLayoutParams(lp);
        return b;
    }

    private TextView text(String s,int sp,int c,boolean bold){
        TextView t=new TextView(this);
        t.setText(s);t.setTextSize(sp);t.setTextColor(c);
        if(bold)t.setTypeface(null,Typeface.BOLD);
        return t;
    }

    public static class ExerciseView extends View{
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Handler h=new Handler(Looper.getMainLooper());
        private boolean running=false;
        private float phase=0;
        private final String name;

        public ExerciseView(android.content.Context c,String n){
            super(c); name=n.toLowerCase(Locale.US); p.setStrokeCap(Paint.Cap.ROUND);
        }

        private final Runnable loop=new Runnable(){
            @Override public void run(){
                if(!running)return;
                phase+=.055f;if(phase>1)phase=0;
                invalidate();h.postDelayed(this,45);
            }
        };

        public void setRunning(boolean x){
            running=x;h.removeCallbacks(loop);
            if(x)h.post(loop);invalidate();
        }

        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            c.drawColor(Color.rgb(247,249,252));
            float w=getWidth(),H=getHeight();
            float q=running?(float)((1-Math.cos(phase*2*Math.PI))/2):0f;

            p.setColor(Color.rgb(220,225,232));p.setStrokeWidth(4);
            c.drawLine(w*.08f,H*.86f,w*.92f,H*.86f,p);

            if(name.contains("squat")||name.contains("lunge")||name.contains("calf")||name.contains("wall")){
                drawLeg(c,w,H,q);
            }else if(name.contains("push")||name.contains("plank")){
                drawPush(c,w,H,q);
            }else{
                drawStand(c,w,H,q);
            }

            p.setColor(Color.rgb(47,113,229));p.setTextSize(Math.max(28,H*.055f));
            p.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawText(running?"KEEP GOING":"READY",w*.34f,H*.12f,p);
        }

        private void limb(Canvas c,float x1,float y1,float x2,float y2,int color,float sw){
            p.setColor(color);p.setStrokeWidth(sw);c.drawLine(x1,y1,x2,y2,p);
        }

        private void drawStand(Canvas c,float w,float H,float q){
            float cx=w*.5f, top=H*.25f;
            float bob=H*.04f*q;
            p.setColor(Color.rgb(226,160,122));c.drawCircle(cx,top+bob,H*.055f,p);
            limb(c,cx,top+H*.06f+bob,cx,top+H*.35f+bob,Color.rgb(47,113,229),36);
            float arm=H*(.14f+.08f*q);
            limb(c,cx,top+H*.15f+bob,cx-w*.18f,top+arm,Color.rgb(226,160,122),18);
            limb(c,cx,top+H*.15f+bob,cx+w*.18f,top+arm,Color.rgb(226,160,122),18);
            limb(c,cx,top+H*.35f+bob,cx-w*.11f,H*.82f,Color.rgb(35,40,48),23);
            limb(c,cx,top+H*.35f+bob,cx+w*.11f,H*.82f,Color.rgb(35,40,48),23);
        }

        private void drawLeg(Canvas c,float w,float H,float q){
            float cx=w*.5f;
            float hipY=H*(.51f+.12f*q);
            p.setColor(Color.rgb(226,160,122));c.drawCircle(cx,H*(.26f+.05f*q),H*.055f,p);
            limb(c,cx,H*(.32f+.05f*q),cx,hipY,Color.rgb(47,113,229),38);
            limb(c,cx,hipY,cx-w*.14f,H*.70f,Color.rgb(35,40,48),24);
            limb(c,cx-w*.14f,H*.70f,cx-w*.22f,H*.84f,Color.rgb(35,40,48),24);
            limb(c,cx,hipY,cx+w*.14f,H*.70f,Color.rgb(35,40,48),24);
            limb(c,cx+w*.14f,H*.70f,cx+w*.22f,H*.84f,Color.rgb(35,40,48),24);
            limb(c,cx,H*.39f,cx-w*.17f,H*(.48f+.05f*q),Color.rgb(226,160,122),17);
            limb(c,cx,H*.39f,cx+w*.17f,H*(.48f+.05f*q),Color.rgb(226,160,122),17);
        }

        private void drawPush(Canvas c,float w,float H,float q){
            float drop=H*.16f*q;
            float shoulderX=w*.64f,shoulderY=H*.43f+drop;
            float hipX=w*.40f,hipY=H*.49f+drop*.75f;
            float handX=w*.69f,handY=H*.82f;
            float footX=w*.17f,footY=H*.82f;
            p.setColor(Color.rgb(226,160,122));
            c.drawCircle(w*.73f,shoulderY-H*.07f,H*.055f,p);
            limb(c,shoulderX,shoulderY,hipX,hipY,Color.rgb(47,113,229),38);
            limb(c,shoulderX,shoulderY,handX,handY,Color.rgb(226,160,122),19);
            limb(c,hipX,hipY,footX,footY,Color.rgb(35,40,48),24);
        }
    }
}
