package com.foridul.gym;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.widget.*;

public class MainActivity extends Activity {
    private LinearLayout root;
    private EditText weightInput, heightInput;
    private TextView bmiResult, progressText;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(11,16,22));
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(34,22,34,40);
        scroll.addView(root);

        addText("FORIDUL GYM",42,Color.rgb(20,210,160),true);
        addText("Native Android • Offline Ready",22,Color.LTGRAY,false);

        section("Quick Start");
        Button start = button("Start Workout");
        start.setOnClickListener(v -> startActivity(new Intent(this, PushUpActivity.class)));

        section("Workout Routines");
        Button push = button("Push Day");
        push.setOnClickListener(v -> startActivity(new Intent(this, PushUpActivity.class)));
        Button pull = button("Pull Day");
        pull.setOnClickListener(v -> openRoutine("Pull Day"));
        Button leg = button("Leg Day");
        leg.setOnClickListener(v -> openRoutine("Leg Day"));

        section("BMI Calculator");
        weightInput = input("Weight (kg)");
        heightInput = input("Height (cm)");
        Button calc = button("Calculate BMI");
        bmiResult = addText("BMI: --",22,Color.WHITE,false);
        calc.setOnClickListener(v -> calcBMI());

        section("Progress");
        progressText = addText("",22,Color.WHITE,false);
        updateProgress();

        setContentView(scroll);
    }

    @Override protected void onResume() {
        super.onResume();
        if (progressText != null) updateProgress();
    }

    private void openRoutine(String type) {
        Intent i = new Intent(this, WorkoutActivity.class);
        i.putExtra("workout_type", type);
        startActivity(i);
    }

    private void updateProgress() {
        int c = getSharedPreferences("gym_prefs", MODE_PRIVATE).getInt("workouts_completed",0);
        progressText.setText("Workouts completed: " + c);
    }

    private void calcBMI() {
        try {
            double w=Double.parseDouble(weightInput.getText().toString());
            double h=Double.parseDouble(heightInput.getText().toString())/100.0;
            bmiResult.setText(String.format("BMI: %.1f", w/(h*h)));
        } catch(Exception e) { bmiResult.setText("Enter valid weight and height"); }
    }

    private void section(String s) { addText(s,28,Color.WHITE,true).setPadding(0,26,0,10); }

    private TextView addText(String s,int sp,int color,boolean bold) {
        TextView t=new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        if(bold)t.setTypeface(null,android.graphics.Typeface.BOLD);
        t.setPadding(0,6,0,6);
        root.addView(t);
        return t;
    }

    private Button button(String s) {
        Button b=new Button(this);
        b.setText(s); b.setTextSize(20); b.setTextColor(Color.BLACK);
        b.setBackgroundColor(Color.rgb(20,210,160));
        b.setMinHeight(120); b.setPadding(18,18,18,18);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0,8,0,10);
        root.addView(b,lp);
        return b;
    }

    private EditText input(String hint) {
        EditText e=new EditText(this);
        e.setHint(hint); e.setHintTextColor(Color.GRAY); e.setTextColor(Color.WHITE); e.setTextSize(20);
        e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setBackgroundColor(Color.rgb(26,35,46)); e.setPadding(26,12,26,12);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,98);
        lp.setMargins(0,6,0,8); root.addView(e,lp);
        return e;
    }
}
