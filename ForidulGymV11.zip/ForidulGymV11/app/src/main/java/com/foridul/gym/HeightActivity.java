package com.foridul.gym;
import android.os.*;import android.content.*;import android.graphics.*;import android.view.*;import android.widget.*;
public class HeightActivity extends SetupBase{
 NumberPicker p; boolean cm=true; Button unit;
 public void onCreate(Bundle b){super.onCreate(b);base("How tall are you?");unit=choice("Unit: cm   (tap for ft & in)");p=new NumberPicker(this);setCm();root.addView(p,new LinearLayout.LayoutParams(-1,0,1));unit.setOnClickListener(v->{cm=!cm;if(cm)setCm();else setFt();});Button c=choice("CONTINUE");c.setOnClickListener(v->{int val=p.getValue();int centimeters=cm?val:(int)Math.round(val*2.54);getSharedPreferences("gym_prefs",0).edit().putInt("height_cm",centimeters).apply();startActivity(new Intent(this,WeightActivity.class));});}
 void setCm(){p.setDisplayedValues(null);p.setMinValue(120);p.setMaxValue(220);p.setValue(165);unit.setText("Unit: cm   (tap for ft & in)");}
 void setFt(){p.setDisplayedValues(null);p.setMinValue(48);p.setMaxValue(84);p.setValue(62);String[] a=new String[37];for(int i=48;i<=84;i++)a[i-48]=(i/12)+"' "+(i%12)+"\"";p.setDisplayedValues(a);unit.setText("Unit: ft & in   (tap for cm)");}
}