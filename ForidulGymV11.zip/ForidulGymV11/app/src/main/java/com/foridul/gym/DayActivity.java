package com.foridul.gym;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;

public class DayActivity extends Activity {
    private int day;
    private LinearLayout root;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        day=getIntent().getIntExtra("day",1);

        ScrollView scroll=new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(245,247,250));
        root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        Ui.safe(this,root,22,18,22,30);
        scroll.addView(root);

        addHeader();
        String type=WorkoutData.typeForDay(day);
        if("REST".equals(type)) addRestDay();
        else addWorkoutDay();

        setContentView(scroll);
    }

    private void addHeader(){
        TextView title=text("Day "+day,28,Color.rgb(30,30,30),true);
        title.setGravity(Gravity.CENTER);
        root.addView(title);
        TextView type=text(WorkoutData.titleForDay(day),15,Color.rgb(47,113,229),true);
        type.setGravity(Gravity.CENTER);
        type.setPadding(0,2,0,12);
        root.addView(type);
    }

    private void addRestDay(){
        LinearLayout card=card();
        TextView big=text("REST DAY",24,Color.rgb(45,45,45),true);
        big.setGravity(Gravity.CENTER);
        card.addView(big);
        TextView msg=text("Recovery is part of training.\nLight stretching, good food and enough sleep.",15,Color.DKGRAY,false);
        msg.setGravity(Gravity.CENTER);
        msg.setPadding(0,10,0,16);
        card.addView(msg);
        Button done=button("MARK REST DAY COMPLETE");
        card.addView(done);
        done.setOnClickListener(v->{ markComplete(); finish(); });
        root.addView(card);
    }

    private void addWorkoutDay(){
        String goal=getSharedPreferences("gym_prefs",0).getString("goal","GAIN");
        String[][] ex=WorkoutData.exercisesForDay(day,goal);

        LinearLayout stats=card();
        stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.setGravity(Gravity.CENTER);
        stats.addView(stat(ex.length+"","Exercises"),new LinearLayout.LayoutParams(0,-2,1));
        stats.addView(stat(WorkoutData.estimatedMinutes(day)+" min","Time"),new LinearLayout.LayoutParams(0,-2,1));
        stats.addView(stat(WorkoutData.estimatedCalories(day)+"","Calories"),new LinearLayout.LayoutParams(0,-2,1));
        root.addView(stats);

        TextView label=text("Exercises",18,Color.rgb(30,30,30),true);
        label.setPadding(2,18,0,10);
        root.addView(label);

        for(int i=0;i<ex.length;i++){
            final int index=i;
            LinearLayout row=card();
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);

            TextView icon=text(String.valueOf(i+1),17,Color.WHITE,true);
            icon.setGravity(Gravity.CENTER);
            GradientDrawable c=new GradientDrawable();
            c.setShape(GradientDrawable.OVAL);
            c.setColor(Color.rgb(47,113,229));
            icon.setBackground(c);
            row.addView(icon,new LinearLayout.LayoutParams(48,48));

            LinearLayout info=new LinearLayout(this);
            info.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(0,-2,1);
            ip.setMargins(14,0,6,0);
            row.addView(info,ip);
            info.addView(text(ex[i][0],16,Color.rgb(35,35,35),true));
            String detail="time".equals(ex[i][2]) ? ex[i][1]+" sec" : "× "+ex[i][1];
            info.addView(text(detail,13,Color.GRAY,false));

            TextView go=text("›",23,Color.GRAY,true);
            row.addView(go,new LinearLayout.LayoutParams(36,48));
            row.setOnClickListener(v->openExercise(index));

            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
            lp.setMargins(0,0,0,10);
            root.addView(row,lp);
        }

        Button start=button("START");
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);
        sp.setMargins(0,10,0,8);
        root.addView(start,sp);
        start.setOnClickListener(v->openExercise(0));
    }

    private LinearLayout stat(String value,String label){
        LinearLayout x=new LinearLayout(this);
        x.setOrientation(LinearLayout.VERTICAL);
        x.setGravity(Gravity.CENTER);
        x.addView(center(text(value,17,Color.rgb(35,35,35),true)));
        x.addView(center(text(label,12,Color.GRAY,false)));
        return x;
    }

    private TextView center(TextView t){ t.setGravity(Gravity.CENTER); return t; }

    private void openExercise(int index){
        Intent i=new Intent(this,ExerciseActivity.class);
        i.putExtra("day",day);
        i.putExtra("index",index);
        startActivity(i);
    }

    private void markComplete(){
        int old=getSharedPreferences("gym_prefs",MODE_PRIVATE).getInt("completed_day",0);
        if(day>old) getSharedPreferences("gym_prefs",MODE_PRIVATE).edit().putInt("completed_day",day).apply();
        Toast.makeText(this,"Day "+day+" completed!",Toast.LENGTH_SHORT).show();
    }

    private LinearLayout card(){
        LinearLayout x=new LinearLayout(this);
        x.setOrientation(LinearLayout.VERTICAL);
        x.setPadding(18,16,18,16);
        GradientDrawable bg=new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(20);
        x.setBackground(bg);
        return x;
    }

    private Button button(String s){
        Button b=new Button(this);
        b.setText(s); b.setTextSize(15); b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.rgb(47,113,229));
        b.setMinHeight(54); b.setPadding(14,10,14,10);
        return b;
    }

    private TextView text(String s,int sp,int color,boolean bold){
        TextView t=new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        if(bold)t.setTypeface(null,Typeface.BOLD);
        return t;
    }
}
