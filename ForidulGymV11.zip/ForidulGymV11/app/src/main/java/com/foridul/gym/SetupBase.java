package com.foridul.gym;
import android.app.*;import android.graphics.*;import android.os.*;import android.view.*;import android.widget.*;
public class SetupBase extends Activity{
 LinearLayout root;
 public void base(String title){
  getWindow().setStatusBarColor(Color.WHITE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
  root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(248,249,252));Ui.safe(this,root,30,28,30,28);
  TextView logo=Ui.text(this,"FORIDUL GYM",18,Ui.blue(),true);root.addView(logo);
  TextView h=Ui.text(this,title,31,Color.rgb(25,25,28),true);h.setPadding(0,35,0,28);root.addView(h);setContentView(root);
 }
 Button choice(String s){Button b=Ui.button(this,s);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,8,0,8);root.addView(b,p);return b;}
}