package com.foridul.gym;
import android.os.*;import android.content.*;import android.view.*;import android.widget.*;
public class WeightActivity extends SetupBase{
 NumberPicker p; boolean kg=true; Button unit;
 public void onCreate(Bundle b){super.onCreate(b);base("What's your weight?");unit=choice("Unit: kg   (tap for lb)");p=new NumberPicker(this);setKg();root.addView(p,new LinearLayout.LayoutParams(-1,0,1));unit.setOnClickListener(v->{kg=!kg;if(kg)setKg();else setLb();});Button c=choice("CONTINUE");c.setOnClickListener(v->{int val=p.getValue();int kilos=kg?val:(int)Math.round(val/2.20462);getSharedPreferences("gym_prefs",0).edit().putInt("weight_kg",kilos).apply();startActivity(new Intent(this,GoalActivity.class));});}
 void setKg(){p.setDisplayedValues(null);p.setMinValue(35);p.setMaxValue(180);p.setValue(65);unit.setText("Unit: kg   (tap for lb)");}
 void setLb(){p.setDisplayedValues(null);p.setMinValue(77);p.setMaxValue(397);p.setValue(143);unit.setText("Unit: lb   (tap for kg)");}
}