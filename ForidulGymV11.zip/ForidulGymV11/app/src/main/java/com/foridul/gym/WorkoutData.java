package com.foridul.gym;
public final class WorkoutData{
 private WorkoutData(){}
 public static String typeForDay(int day){int m=(day-1)%4;if(m==0)return "PUSH";if(m==1)return "PULL";if(m==2)return "LEG";return "REST";}
 public static String titleForDay(int d){String t=typeForDay(d);return "REST".equals(t)?"REST DAY":t+" DAY";}
 public static String[][] exercisesForDay(int d){return exercisesForDay(d,"GAIN");}
 public static String[][] exercisesForDay(int d,String goal){
  String t=typeForDay(d);int lv=Math.min(4,1+(d-1)/8);
  if("LOSE".equals(goal)){
   if("PUSH".equals(t))return new String[][]{{"Jumping Jacks",rep(20,lv,5),"rep"},{"Push Ups",rep(8,lv,2),"rep"},{"Mountain Climbers",rep(20,lv,4),"rep"},{"Shoulder Taps",rep(12,lv,2),"rep"},{"Plank",sec(25,lv,5),"time"}};
   if("PULL".equals(t))return new String[][]{{"High Knees",rep(24,lv,6),"rep"},{"Bent Over Row",rep(10,lv,2),"rep"},{"Superman",rep(12,lv,2),"rep"},{"Mountain Climbers",rep(20,lv,4),"rep"},{"Back Hold",sec(20,lv,5),"time"}};
   if("LEG".equals(t))return new String[][]{{"Squats",rep(15,lv,3),"rep"},{"Lunges",rep(12,lv,2),"rep"},{"High Knees",rep(24,lv,6),"rep"},{"Glute Bridge",rep(12,lv,2),"rep"},{"Wall Sit",sec(25,lv,5),"time"}};
  }else{
   if("PUSH".equals(t))return new String[][]{{"Push Ups",rep(10,lv,2),"rep"},{"Shoulder Taps",rep(12,lv,2),"rep"},{"Knee Push Ups",rep(10,lv,2),"rep"},{"Tricep Dips",rep(8,lv,2),"rep"},{"Plank",sec(25,lv,5),"time"}};
   if("PULL".equals(t))return new String[][]{{"Bent Over Row",rep(10,lv,2),"rep"},{"Bicep Curls",rep(12,lv,2),"rep"},{"Reverse Fly",rep(10,lv,2),"rep"},{"Superman",rep(12,lv,2),"rep"},{"Back Hold",sec(20,lv,5),"time"}};
   if("LEG".equals(t))return new String[][]{{"Squats",rep(12,lv,3),"rep"},{"Lunges",rep(10,lv,2),"rep"},{"Calf Raises",rep(15,lv,3),"rep"},{"Glute Bridge",rep(12,lv,2),"rep"},{"Wall Sit",sec(25,lv,5),"time"}};
  }return new String[0][0];
 }
 static String rep(int b,int l,int a){return ""+(b+(l-1)*a);}static String sec(int b,int l,int a){return ""+(b+(l-1)*a);}
 public static int estimatedMinutes(int d){return "REST".equals(typeForDay(d))?0:8+((d-1)/8)*2;}
 public static int estimatedCalories(int d){return "REST".equals(typeForDay(d))?0:45+((d-1)/4)*5;}
}