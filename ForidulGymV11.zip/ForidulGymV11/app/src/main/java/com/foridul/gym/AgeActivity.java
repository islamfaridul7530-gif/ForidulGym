package com.foridul.gym;
import android.os.*;import android.content.*;import android.graphics.*;import android.view.*;import android.widget.*;
public class AgeActivity extends SetupBase{
 NumberPicker p;
 public void onCreate(Bundle b){super.onCreate(b);base("How old are you?");p=new NumberPicker(this);p.setMinValue(13);p.setMaxValue(80);p.setValue(22);root.addView(p,new LinearLayout.LayoutParams(-1,0,1));Button c=choice("CONTINUE");c.setOnClickListener(v->{getSharedPreferences("gym_prefs",0).edit().putInt("age",p.getValue()).apply();startActivity(new Intent(this,HeightActivity.class));});}
}