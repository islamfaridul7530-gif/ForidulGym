package com.foridul.gym;
import android.app.*; import android.graphics.*; import android.graphics.drawable.*; import android.view.*; import android.widget.*; import android.content.*;
public final class Ui{
 public static int blue(){return Color.rgb(45,105,225);}
 public static void safe(Activity a, View v,int l,int top,int r,int b){int id=a.getResources().getIdentifier("status_bar_height","dimen","android");int h=id>0?a.getResources().getDimensionPixelSize(id):0;v.setPadding(l,h+top,r,b);}
 public static TextView text(Context c,String s,int z,int col,boolean bold){TextView t=new TextView(c);t.setText(s);t.setTextSize(z);t.setTextColor(col);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
 public static Button button(Context c,String s){Button b=new Button(c);b.setText(s);b.setTextSize(15);b.setTextColor(Color.WHITE);GradientDrawable g=new GradientDrawable();g.setColor(blue());g.setCornerRadius(48);b.setBackground(g);b.setMinHeight(58);return b;}
 public static LinearLayout card(Context c){LinearLayout x=new LinearLayout(c);x.setOrientation(LinearLayout.VERTICAL);x.setPadding(22,20,22,20);GradientDrawable g=new GradientDrawable();g.setColor(Color.WHITE);g.setCornerRadius(28);x.setBackground(g);return x;}
 public static LinearLayout nav(Activity a,String selected){
  LinearLayout n=new LinearLayout(a);n.setOrientation(LinearLayout.HORIZONTAL);n.setGravity(Gravity.CENTER);n.setPadding(4,6,4,6);n.setBackgroundColor(Color.WHITE);
  String[] names={"Training","Reports","Me"}; Class<?>[] cls={MainActivity.class,ReportsActivity.class,MeActivity.class};
  int[] normal={R.drawable.ic_training,R.drawable.ic_reports,R.drawable.ic_me};
  int[] sel={R.drawable.ic_training_sel,R.drawable.ic_reports_sel,R.drawable.ic_me_sel};
  for(int i=0;i<3;i++){final Class<?> c=cls[i];boolean on=names[i].equals(selected);
   LinearLayout tab=new LinearLayout(a);tab.setOrientation(LinearLayout.VERTICAL);tab.setGravity(Gravity.CENTER);
   ImageView iv=new ImageView(a);iv.setImageResource(on?sel[i]:normal[i]);tab.addView(iv,new LinearLayout.LayoutParams(46,46));
   TextView t=text(a,names[i],12,on?blue():Color.GRAY,on);t.setGravity(Gravity.CENTER);tab.addView(t);
   n.addView(tab,new LinearLayout.LayoutParams(0,-2,1));
   tab.setOnClickListener(v->{if(!a.getClass().equals(c)){a.startActivity(new Intent(a,c));a.finish();}});
  } return n;
 }
}