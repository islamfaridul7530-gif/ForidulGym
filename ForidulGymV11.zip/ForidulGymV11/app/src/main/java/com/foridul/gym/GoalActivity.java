package com.foridul.gym;
import android.os.*;import android.content.*;import android.widget.*;
public class GoalActivity extends SetupBase{
 public void onCreate(Bundle b){super.onCreate(b);base("What's your goal?");Button g=choice("GAIN MUSCLE"),l=choice("LOSE WEIGHT");g.setOnClickListener(v->go("GAIN"));l.setOnClickListener(v->go("LOSE"));}
 void go(String goal){getSharedPreferences("gym_prefs",0).edit().putString("goal",goal).putBoolean("setup_complete",true).apply();Intent i=new Intent(this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);finishAffinity();}
}