package com.foridul.gym;

public final class WorkoutData {
    private WorkoutData(){}

    public static String typeForDay(int day){
        int m=(day-1)%4;
        if(m==0) return "PUSH";
        if(m==1) return "PULL";
        if(m==2) return "LEG";
        return "REST";
    }

    public static String titleForDay(int day){
        String t=typeForDay(day);
        if("REST".equals(t)) return "REST DAY";
        return t+" DAY";
    }

    public static String[][] exercisesForDay(int day){
        String type=typeForDay(day);
        int level=1+(day-1)/8;
        if(level>4) level=4;

        if("PUSH".equals(type)){
            return new String[][]{
                {"Push Ups", reps(10,level,2), "rep"},
                {"Shoulder Taps", reps(12,level,2), "rep"},
                {"Knee Push Ups", reps(10,level,2), "rep"},
                {"Tricep Dips", reps(8,level,2), "rep"},
                {"Plank", secs(25,level,5), "time"}
            };
        }
        if("PULL".equals(type)){
            return new String[][]{
                {"Bent Over Row", reps(10,level,2), "rep"},
                {"Bicep Curls", reps(12,level,2), "rep"},
                {"Reverse Fly", reps(10,level,2), "rep"},
                {"Superman", reps(12,level,2), "rep"},
                {"Back Hold", secs(20,level,5), "time"}
            };
        }
        if("LEG".equals(type)){
            return new String[][]{
                {"Squats", reps(12,level,3), "rep"},
                {"Lunges", reps(10,level,2), "rep"},
                {"Calf Raises", reps(15,level,3), "rep"},
                {"Glute Bridge", reps(12,level,2), "rep"},
                {"Wall Sit", secs(25,level,5), "time"}
            };
        }
        return new String[0][0];
    }

    private static String reps(int base,int level,int add){ return String.valueOf(base+(level-1)*add); }
    private static String secs(int base,int level,int add){ return String.valueOf(base+(level-1)*add); }

    public static int estimatedMinutes(int day){
        if("REST".equals(typeForDay(day))) return 0;
        return 8 + ((day-1)/8)*2;
    }

    public static int estimatedCalories(int day){
        if("REST".equals(typeForDay(day))) return 0;
        return 45 + ((day-1)/4)*5;
    }
}
